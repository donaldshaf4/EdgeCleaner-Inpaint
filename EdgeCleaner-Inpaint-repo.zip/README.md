# EdgeCleaner Inpaint Pro v3

Android-приложение для локального восстановления областей на собственных/разрешённых фото и видео.

## Видео v3
- пауза/продолжить;
- таймлайн и точная перемотка;
- несколько масок по времени;
- каждая точка маски действует с её времени до следующей;
- «Без маски отсюда» для участков, где watermark исчезает;
- новый edge-guided fill без зеркального отражения соседнего фрагмента;
- мягкое смешивание по краям маски.

## Фото
OpenCV Telea inpainting.

## Сборка
GitHub Actions workflow лежит в `.github/workflows/build-apk.yml`.

## Release signing / updates
The app supports release signing through environment variables:
`ANDROID_KEYSTORE_PATH`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`.
The GitHub workflow outside this ZIP can inject the persistent signing key from GitHub Actions secrets.
Never commit the private `.jks` signing key to a public repository.


## UX update
- No default mask is shown when media opens.
- The mask appears only after the user drags over a watermark.
- Reset/Clear removes the current mask instead of recreating a preset rectangle.
