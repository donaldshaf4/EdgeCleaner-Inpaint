# EdgeCleaner Inpaint Android

Offline Android app for restoring pixels under a user-selected watermark/overlay area in media you own or have permission to edit.

## Version 2.0

### Photos

- Drag a rectangular mask directly over the unwanted overlay.
- Uses OpenCV `Photo.inpaint(..., INPAINT_TELEA)` locally on-device.
- Preserves the original image dimensions; it does **not** crop the frame.
- Adjustable inpainting radius (3–20 px).

### Videos

- Drag the same type of mask over the watermark area.
- Uses a custom Media3/OpenGL effect on every frame.
- The shader reconstructs the selected rectangle from mirrored neighboring pixels on all four sides and distance-weighted blending.
- Keeps the full video dimensions and exports H.264/AAC with the audio track.
- This video mode is a fast spatial restoration method, not a generative AI model. Complex moving backgrounds can still show artifacts.

All processing is local. Files are selected with Android's system document picker and are not uploaded to a server.

Use only on media you own or are authorized to modify.

## Build configuration

- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- JDK 17
- compileSdk / targetSdk 36
- AndroidX Media3 1.11.1
- OpenCV Android AAR 4.14.0 from Maven Central
- minSdk 23 (Android 6.0+)

## Build with GitHub Actions

Push the project to a GitHub repository and run **Build APK**. The workflow uploads `app-debug.apk` as an artifact.

## Local build

Install Android SDK platform 36 and build-tools 36.0.0, then run:

```bash
gradle :app:assembleDebug
```

APK path:

```text
app/build/outputs/apk/debug/app-debug.apk
```
