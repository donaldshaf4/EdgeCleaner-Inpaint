#version 100
precision highp float;

uniform sampler2D uTexSampler;
uniform float uEnabled;
uniform vec4 uCoreRect;   // bounding box: left, bottom, right, top
uniform vec4 uOuterRect;
uniform vec2 uFeather;
uniform vec2 uTexel;
uniform vec4 uSideWeights; // left, right, bottom, top
uniform vec4 uBrush0;
uniform vec4 uBrush1;
uniform vec4 uBrush2;
uniform vec4 uBrush3;
uniform vec4 uBrush4;
uniform vec4 uBrush5;
uniform vec4 uBrush6;
uniform vec4 uBrush7;
varying vec2 vTexSamplingCoord;

float ellipseMask(vec2 uv, vec4 e) {
  if (e.z <= 0.0 || e.w <= 0.0) return 0.0;
  vec2 q = (uv - e.xy) / max(e.zw, vec2(0.00001));
  float d = length(q);
  return 1.0 - smoothstep(0.82, 1.18, d);
}

float brushMask(vec2 uv) {
  float a = ellipseMask(uv, uBrush0);
  a = max(a, ellipseMask(uv, uBrush1));
  a = max(a, ellipseMask(uv, uBrush2));
  a = max(a, ellipseMask(uv, uBrush3));
  a = max(a, ellipseMask(uv, uBrush4));
  a = max(a, ellipseMask(uv, uBrush5));
  a = max(a, ellipseMask(uv, uBrush6));
  a = max(a, ellipseMask(uv, uBrush7));
  return a;
}

vec4 sampleVertical(float x, float y) {
  float sy = max(uFeather.y * 1.35, uTexel.y * 7.0);
  float sx = max(uFeather.x * 0.55, uTexel.x * 3.0);
  return (
      texture2D(uTexSampler, vec2(clamp(x - sx, 0.0, 1.0), clamp(y - sy, 0.0, 1.0))) * 0.10 +
      texture2D(uTexSampler, vec2(x, clamp(y - sy * 0.55, 0.0, 1.0))) * 0.20 +
      texture2D(uTexSampler, vec2(x, y)) * 0.40 +
      texture2D(uTexSampler, vec2(x, clamp(y + sy * 0.55, 0.0, 1.0))) * 0.20 +
      texture2D(uTexSampler, vec2(clamp(x + sx, 0.0, 1.0), clamp(y + sy, 0.0, 1.0))) * 0.10
  );
}

vec4 sampleHorizontal(float x, float y) {
  float sx = max(uFeather.x * 1.35, uTexel.x * 7.0);
  float sy = max(uFeather.y * 0.55, uTexel.y * 3.0);
  return (
      texture2D(uTexSampler, vec2(clamp(x - sx, 0.0, 1.0), clamp(y - sy, 0.0, 1.0))) * 0.10 +
      texture2D(uTexSampler, vec2(clamp(x - sx * 0.55, 0.0, 1.0), y)) * 0.20 +
      texture2D(uTexSampler, vec2(x, y)) * 0.40 +
      texture2D(uTexSampler, vec2(clamp(x + sx * 0.55, 0.0, 1.0), y)) * 0.20 +
      texture2D(uTexSampler, vec2(clamp(x + sx, 0.0, 1.0), clamp(y + sy, 0.0, 1.0))) * 0.10
  );
}

void main() {
  vec2 uv = vTexSamplingCoord;
  vec4 original = texture2D(uTexSampler, uv);
  if (uEnabled < 0.5) {
    gl_FragColor = original;
    return;
  }

  float alpha = brushMask(uv);
  if (alpha <= 0.001) {
    gl_FragColor = original;
    return;
  }

  float ol = uOuterRect.x;
  float ob = uOuterRect.y;
  float orr = uOuterRect.z;
  float ot = uOuterRect.w;
  float marginX = max(uFeather.x * 2.0, uTexel.x * 8.0);
  float marginY = max(uFeather.y * 2.0, uTexel.y * 8.0);

  float xL = clamp(ol - marginX, 0.0, 1.0);
  float xR = clamp(orr + marginX, 0.0, 1.0);
  float yB = clamp(ob - marginY, 0.0, 1.0);
  float yT = clamp(ot + marginY, 0.0, 1.0);

  vec4 cL = sampleVertical(xL, clamp(uv.y, ob, ot));
  vec4 cR = sampleVertical(xR, clamp(uv.y, ob, ot));
  vec4 cB = sampleHorizontal(clamp(uv.x, ol, orr), yB);
  vec4 cT = sampleHorizontal(clamp(uv.x, ol, orr), yT);

  // Weight sides by clean space available in the frame. A bottom-right watermark therefore
  // primarily uses left/top background instead of inventing mirrored material at the frame edge.
  vec4 w = uSideWeights * uSideWeights;
  float sum = max(0.0001, w.x + w.y + w.z + w.w);
  vec4 restored = (cL * w.x + cR * w.y + cB * w.z + cT * w.w) / sum;

  // A second broad average removes recognizable repeated fragments while keeping large gradients.
  vec4 broad = (cL + cR + cB + cT) * 0.25;
  restored = mix(restored, broad, 0.28);

  // Freehand feathering follows the painted watermark shape, not its rectangular bounding box.
  alpha = alpha * alpha * (3.0 - 2.0 * alpha);
  gl_FragColor = mix(original, restored, alpha);
}
