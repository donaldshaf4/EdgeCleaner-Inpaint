#version 100
precision highp float;

uniform sampler2D uTexSampler;
uniform float uEnabled;
uniform vec4 uCoreRect;   // left, bottom, right, top
uniform vec4 uOuterRect;  // feathered region
uniform vec2 uFeather;
uniform vec2 uTexel;
varying vec2 vTexSamplingCoord;

vec4 edgeVertical(float x, float y) {
  float sy = max(uFeather.y * 0.9, uTexel.y * 4.0);
  float sx = max(uFeather.x * 0.65, uTexel.x * 3.0);
  return (
      texture2D(uTexSampler, vec2(clamp(x - sx, 0.0, 1.0), clamp(y - sy, 0.0, 1.0))) * 0.10 +
      texture2D(uTexSampler, vec2(x, clamp(y - sy * 0.5, 0.0, 1.0))) * 0.20 +
      texture2D(uTexSampler, vec2(x, y)) * 0.40 +
      texture2D(uTexSampler, vec2(x, clamp(y + sy * 0.5, 0.0, 1.0))) * 0.20 +
      texture2D(uTexSampler, vec2(clamp(x + sx, 0.0, 1.0), clamp(y + sy, 0.0, 1.0))) * 0.10
  );
}

vec4 edgeHorizontal(float x, float y) {
  float sx = max(uFeather.x * 0.9, uTexel.x * 4.0);
  float sy = max(uFeather.y * 0.65, uTexel.y * 3.0);
  return (
      texture2D(uTexSampler, vec2(clamp(x - sx, 0.0, 1.0), clamp(y - sy, 0.0, 1.0))) * 0.10 +
      texture2D(uTexSampler, vec2(clamp(x - sx * 0.5, 0.0, 1.0), y)) * 0.20 +
      texture2D(uTexSampler, vec2(x, y)) * 0.40 +
      texture2D(uTexSampler, vec2(clamp(x + sx * 0.5, 0.0, 1.0), y)) * 0.20 +
      texture2D(uTexSampler, vec2(clamp(x + sx, 0.0, 1.0), clamp(y + sy, 0.0, 1.0))) * 0.10
  );
}

void main() {
  vec2 uv = vTexSamplingCoord;
  vec4 original = texture2D(uTexSampler, uv);
  if (uEnabled < 0.5) {
    gl_FragColor = original;
    return;
  }

  float l = uCoreRect.x;
  float b = uCoreRect.y;
  float r = uCoreRect.z;
  float t = uCoreRect.w;
  float ol = uOuterRect.x;
  float ob = uOuterRect.y;
  float orr = uOuterRect.z;
  float ot = uOuterRect.w;

  if (uv.x < ol || uv.x > orr || uv.y < ob || uv.y > ot) {
    gl_FragColor = original;
    return;
  }

  // Clean sampling lines stay outside the whole feathered area. Unlike mirror fill, a pixel is
  // never reflected across an edge, so nearby faces/hands do not appear as reversed copies.
  float marginX = max(uFeather.x * 1.4, uTexel.x * 5.0);
  float marginY = max(uFeather.y * 1.4, uTexel.y * 5.0);
  float xL = clamp(ol - marginX, 0.0, 1.0);
  float xR = clamp(orr + marginX, 0.0, 1.0);
  float yB = clamp(ob - marginY, 0.0, 1.0);
  float yT = clamp(ot + marginY, 0.0, 1.0);

  float sampleY = clamp(uv.y, ob, ot);
  float sampleX = clamp(uv.x, ol, orr);
  vec4 cL = edgeVertical(xL, sampleY);
  vec4 cR = edgeVertical(xR, sampleY);
  vec4 cB = edgeHorizontal(sampleX, yB);
  vec4 cT = edgeHorizontal(sampleX, yT);

  float tx = clamp((uv.x - l) / max(r - l, 0.00001), 0.0, 1.0);
  float ty = clamp((uv.y - b) / max(t - b, 0.00001), 0.0, 1.0);
  vec4 horizontalFill = mix(cL, cR, tx);
  vec4 verticalFill = mix(cB, cT, ty);

  float coreW = max(r - l, 0.00001);
  float coreH = max(t - b, 0.00001);
  // Prefer the closer pair of borders. Wide/short watermark -> top/bottom carry more weight.
  float verticalWeight = clamp(coreW / (coreW + coreH), 0.25, 0.75);
  vec4 restored = mix(horizontalFill, verticalFill, verticalWeight);

  bool inCore = uv.x >= l && uv.x <= r && uv.y >= b && uv.y <= t;
  if (inCore) {
    gl_FragColor = restored;
    return;
  }

  float dx = 0.0;
  if (uv.x < l) dx = l - uv.x;
  else if (uv.x > r) dx = uv.x - r;
  float dy = 0.0;
  if (uv.y < b) dy = b - uv.y;
  else if (uv.y > t) dy = uv.y - t;

  float ringDistance = max(dx / max(uFeather.x * 2.7, 0.00001),
                           dy / max(uFeather.y * 2.7, 0.00001));
  float alpha = 1.0 - smoothstep(0.0, 1.0, ringDistance);
  // Smooth cubic alpha avoids a visible rectangular edge.
  alpha = alpha * alpha * (3.0 - 2.0 * alpha);
  gl_FragColor = mix(original, restored, alpha);
}
