#version 100
precision highp float;

uniform sampler2D uTexSampler;
uniform vec4 uMaskRect; // left, bottom, right, top
uniform vec2 uFeather;  // x/y feather in normalized texture coordinates
varying vec2 vTexSamplingCoord;

float safeInv(float v) {
  return 1.0 / max(v, 0.00001);
}

void main() {
  vec2 uv = vTexSamplingCoord;
  vec4 original = texture2D(uTexSampler, uv);

  float left = uMaskRect.x;
  float bottom = uMaskRect.y;
  float right = uMaskRect.z;
  float top = uMaskRect.w;

  if (uv.x < left || uv.x > right || uv.y < bottom || uv.y > top) {
    gl_FragColor = original;
    return;
  }

  float dl = max(uv.x - left, 0.0);
  float dr = max(right - uv.x, 0.0);
  float db = max(uv.y - bottom, 0.0);
  float dt = max(top - uv.y, 0.0);

  // Mirror each masked pixel across every mask edge. This preserves moving background detail
  // better than a flat blur/solid overlay and is stable from frame to frame.
  vec2 pL = vec2(clamp(left - dl - uFeather.x, 0.0, 1.0), uv.y);
  vec2 pR = vec2(clamp(right + dr + uFeather.x, 0.0, 1.0), uv.y);
  vec2 pB = vec2(uv.x, clamp(bottom - db - uFeather.y, 0.0, 1.0));
  vec2 pT = vec2(uv.x, clamp(top + dt + uFeather.y, 0.0, 1.0));

  vec4 cL = texture2D(uTexSampler, pL);
  vec4 cR = texture2D(uTexSampler, pR);
  vec4 cB = texture2D(uTexSampler, pB);
  vec4 cT = texture2D(uTexSampler, pT);

  float wL = safeInv(dl + uFeather.x);
  float wR = safeInv(dr + uFeather.x);
  float wB = safeInv(db + uFeather.y);
  float wT = safeInv(dt + uFeather.y);
  vec4 restored = (cL * wL + cR * wR + cB * wB + cT * wT) / (wL + wR + wB + wT);

  float edgeDistance = min(min(dl, dr), min(db, dt));
  float feather = max(uFeather.x, uFeather.y) * 2.0;
  float blend = smoothstep(0.0, feather, edgeDistance);
  gl_FragColor = mix(restored, original, 1.0 - blend * 0.98);
}
