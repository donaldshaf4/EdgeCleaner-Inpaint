#version 100
precision highp float;

uniform sampler2D uTexSampler;
uniform sampler2D uMaskSampler;
uniform float uEnabled;
uniform vec4 uOuterRect;     // left, bottom, right, top in GL UV
uniform vec2 uFeather;
uniform vec2 uTexel;
uniform vec4 uSideWeights;   // left, right, bottom, top
uniform float uSmoothStrength;
varying vec2 vTexSamplingCoord;

float maskAt(vec2 uv) {
  // Android Bitmap rows are top-down; video texture coordinates are bottom-up.
  return texture2D(uMaskSampler, vec2(clamp(uv.x, 0.0, 1.0), 1.0 - clamp(uv.y, 0.0, 1.0))).a;
}

vec4 cleanSample(vec2 p, vec2 dir) {
  vec2 tangent = vec2(-dir.y, dir.x);
  vec2 o = tangent * vec2(max(uTexel.x * 1.4, uFeather.x * 0.18),
                          max(uTexel.y * 1.4, uFeather.y * 0.18));
  return texture2D(uTexSampler, clamp(p, 0.0, 1.0)) * 0.52 +
         texture2D(uTexSampler, clamp(p + o, 0.0, 1.0)) * 0.24 +
         texture2D(uTexSampler, clamp(p - o, 0.0, 1.0)) * 0.24;
}

vec4 rayFill(vec2 uv, vec2 dir, float bias, out float weight) {
  vec2 stepV = vec2(max(uTexel.x * 2.2, uFeather.x * 0.28),
                    max(uTexel.y * 2.2, uFeather.y * 0.28));
  weight = 0.0;
  vec4 found = vec4(0.0);
  for (int i = 1; i <= 24; i++) {
    float fi = float(i);
    vec2 p = uv + dir * stepV * fi;
    if (p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0) {
      continue;
    }
    if (maskAt(p) < 0.08) {
      vec2 p2 = p + dir * stepV * 1.5;
      vec4 a = cleanSample(p, dir);
      vec4 b = cleanSample(clamp(p2, 0.0, 1.0), dir);
      found = mix(a, b, 0.22);
      weight = bias / (1.0 + fi * 0.34);
      break;
    }
  }
  return found;
}

void addRay(in vec2 uv, in vec2 dir, in float bias, inout vec4 sum, inout float weightSum) {
  float w = 0.0;
  vec4 s = rayFill(uv, dir, bias, w);
  if (w > 0.0) {
    sum += s * w;
    weightSum += w;
  }
}

void main() {
  vec2 uv = vTexSamplingCoord;
  vec4 original = texture2D(uTexSampler, uv);
  if (uEnabled < 0.5) {
    gl_FragColor = original;
    return;
  }

  if (uv.x < uOuterRect.x || uv.x > uOuterRect.z || uv.y < uOuterRect.y || uv.y > uOuterRect.w) {
    gl_FragColor = original;
    return;
  }

  float m = maskAt(uv);
  if (m <= 0.003) {
    gl_FragColor = original;
    return;
  }

  vec4 sum = vec4(0.0);
  float ws = 0.0;
  float wl = max(0.03, uSideWeights.x);
  float wr = max(0.03, uSideWeights.y);
  float wb = max(0.03, uSideWeights.z);
  float wt = max(0.03, uSideWeights.w);

  addRay(uv, vec2(-1.0,  0.0), wl, sum, ws);
  addRay(uv, vec2( 1.0,  0.0), wr, sum, ws);
  addRay(uv, vec2( 0.0, -1.0), wb, sum, ws);
  addRay(uv, vec2( 0.0,  1.0), wt, sum, ws);

  addRay(uv, vec2(-0.7071, -0.7071), (wl + wb) * 0.44, sum, ws);
  addRay(uv, vec2( 0.7071, -0.7071), (wr + wb) * 0.44, sum, ws);
  addRay(uv, vec2(-0.7071,  0.7071), (wl + wt) * 0.44, sum, ws);
  addRay(uv, vec2( 0.7071,  0.7071), (wr + wt) * 0.44, sum, ws);

  vec4 restored;
  if (ws > 0.0001) {
    restored = sum / ws;
  } else {
    // Rare fallback for a very large mask: take clean colour from just outside its bounding box.
    float xL = clamp(uOuterRect.x - max(uFeather.x * 0.7, uTexel.x * 4.0), 0.0, 1.0);
    float xR = clamp(uOuterRect.z + max(uFeather.x * 0.7, uTexel.x * 4.0), 0.0, 1.0);
    float yB = clamp(uOuterRect.y - max(uFeather.y * 0.7, uTexel.y * 4.0), 0.0, 1.0);
    float yT = clamp(uOuterRect.w + max(uFeather.y * 0.7, uTexel.y * 4.0), 0.0, 1.0);
    restored = (texture2D(uTexSampler, vec2(xL, uv.y)) +
                texture2D(uTexSampler, vec2(xR, uv.y)) +
                texture2D(uTexSampler, vec2(uv.x, yB)) +
                texture2D(uTexSampler, vec2(uv.x, yT))) * 0.25;
  }

  // Only soften the actual mask contour. The centre stays locally reconstructed and textured.
  vec2 f = vec2(max(uFeather.x * 0.34, uTexel.x * 1.8),
                max(uFeather.y * 0.34, uTexel.y * 1.8));
  float around = (maskAt(uv + vec2(f.x, 0.0)) +
                  maskAt(uv - vec2(f.x, 0.0)) +
                  maskAt(uv + vec2(0.0, f.y)) +
                  maskAt(uv - vec2(0.0, f.y))) * 0.25;
  float blurMask = mix(m, around, 0.42 + 0.30 * clamp(uSmoothStrength, 0.0, 1.0));
  float alpha = smoothstep(0.08, 0.82, max(m * 0.88, blurMask));

  // Smoothing now affects only the feathered contour, not the reconstructed texture itself.
  // This avoids the large soft blobs produced by previous builds.
  gl_FragColor = mix(original, restored, alpha);
}
