#version 100
precision highp float;

uniform sampler2D uTexSampler;
uniform float uEnabled;
uniform vec4 uCoreRect;   // left, bottom, right, top
uniform vec4 uOuterRect;  // feathered region
uniform vec2 uFeather;
uniform vec2 uTexel;
varying vec2 vTexSamplingCoord;

vec4 edgeVertical(float x, float y) {
  float sy = max(uFeather.y * 1.15, uTexel.y * 6.0);
  float sx = max(uFeather.x * 0.80, uTexel.x * 4.0);
  return (
      texture2D(uTexSampler, vec2(clamp(x - sx, 0.0, 1.0), clamp(y - sy, 0.0, 1.0))) * 0.12 +
      texture2D(uTexSampler, vec2(clamp(x - sx * 0.35, 0.0, 1.0), clamp(y - sy * 0.45, 0.0, 1.0))) * 0.18 +
      texture2D(uTexSampler, vec2(x, y)) * 0.40 +
      texture2D(uTexSampler, vec2(clamp(x + sx * 0.35, 0.0, 1.0), clamp(y + sy * 0.45, 0.0, 1.0))) * 0.18 +
      texture2D(uTexSampler, vec2(clamp(x + sx, 0.0, 1.0), clamp(y + sy, 0.0, 1.0))) * 0.12
  );
}

vec4 edgeHorizontal(float x, float y) {
  float sx = max(uFeather.x * 1.15, uTexel.x * 6.0);
  float sy = max(uFeather.y * 0.80, uTexel.y * 4.0);
  return (
      texture2D(uTexSampler, vec2(clamp(x - sx, 0.0, 1.0), clamp(y - sy, 0.0, 1.0))) * 0.12 +
      texture2D(uTexSampler, vec2(clamp(x - sx * 0.45, 0.0, 1.0), clamp(y - sy * 0.35, 0.0, 1.0))) * 0.18 +
      texture2D(uTexSampler, vec2(x, y)) * 0.40 +
      texture2D(uTexSampler, vec2(clamp(x + sx * 0.45, 0.0, 1.0), clamp(y + sy * 0.35, 0.0, 1.0))) * 0.18 +
      texture2D(uTexSampler, vec2(clamp(x + sx, 0.0, 1.0), clamp(y + sy, 0.0, 1.0))) * 0.12
  );
}

vec4 cornerSample(float x, float y) {
  float sx = max(uFeather.x, uTexel.x * 5.0);
  float sy = max(uFeather.y, uTexel.y * 5.0);
  return (
      texture2D(uTexSampler, vec2(x, y)) * 0.40 +
      texture2D(uTexSampler, vec2(clamp(x + sx, 0.0, 1.0), y)) * 0.15 +
      texture2D(uTexSampler, vec2(x, clamp(y + sy, 0.0, 1.0))) * 0.15 +
      texture2D(uTexSampler, vec2(clamp(x - sx, 0.0, 1.0), y)) * 0.15 +
      texture2D(uTexSampler, vec2(x, clamp(y - sy, 0.0, 1.0))) * 0.15
  );
}

float roundedMaskAlpha(vec2 uv, vec2 center, vec2 halfSize, float radius, float softness) {
  vec2 q = abs(uv - center) - (halfSize - vec2(radius));
  float dist = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - radius;
  return 1.0 - smoothstep(-softness, softness, dist);
}

void main() {
  vec2 uv = vTexSamplingCoord;
  vec4 original = texture2D(uTexSampler, uv);
  if (uEnabled < 0.5) {
    gl_FragColor = original;
    return;
  }

  float l = uCoreRect.x;
  float b = uCoreRect.y;
  float r = uCoreRect.z;
  float t = uCoreRect.w;
  float ol = uOuterRect.x;
  float ob = uOuterRect.y;
  float orr = uOuterRect.z;
  float ot = uOuterRect.w;

  // Rounded transition region to avoid visible rectangular edges.
  vec2 center = vec2((l + r) * 0.5, (b + t) * 0.5);
  vec2 halfCore = vec2(max((r - l) * 0.5, 0.0001), max((t - b) * 0.5, 0.0001));
  vec2 halfOuter = vec2(max((orr - ol) * 0.5, 0.0001), max((ot - ob) * 0.5, 0.0001));
  float cornerRadius = min(min(halfCore.x, halfCore.y) * 0.55, max(uFeather.x, uFeather.y) * 10.0);
  float outerRadius = cornerRadius + max(uFeather.x, uFeather.y) * 2.0;
  float outerAlpha = roundedMaskAlpha(uv, center, halfOuter, outerRadius, max(uFeather.x, uFeather.y) * 1.8);
  if (outerAlpha <= 0.001) {
    gl_FragColor = original;
    return;
  }

  float marginX = max(uFeather.x * 1.8, uTexel.x * 7.0);
  float marginY = max(uFeather.y * 1.8, uTexel.y * 7.0);
  float xL = clamp(ol - marginX, 0.0, 1.0);
  float xR = clamp(orr + marginX, 0.0, 1.0);
  float yB = clamp(ob - marginY, 0.0, 1.0);
  float yT = clamp(ot + marginY, 0.0, 1.0);

  float sampleY = clamp(uv.y, ob, ot);
  float sampleX = clamp(uv.x, ol, orr);
  vec4 cL = edgeVertical(xL, sampleY);
  vec4 cR = edgeVertical(xR, sampleY);
  vec4 cB = edgeHorizontal(sampleX, yB);
  vec4 cT = edgeHorizontal(sampleX, yT);
  vec4 cBL = cornerSample(xL, yB);
  vec4 cBR = cornerSample(xR, yB);
  vec4 cTL = cornerSample(xL, yT);
  vec4 cTR = cornerSample(xR, yT);

  float tx = clamp((uv.x - l) / max(r - l, 0.00001), 0.0, 1.0);
  float ty = clamp((uv.y - b) / max(t - b, 0.00001), 0.0, 1.0);

  vec4 horizontalFill = mix(cL, cR, tx);
  vec4 verticalFill = mix(cB, cT, ty);
  vec4 cornerTop = mix(cTL, cTR, tx);
  vec4 cornerBottom = mix(cBL, cBR, tx);
  vec4 cornerFill = mix(cornerBottom, cornerTop, ty);

  float coreW = max(r - l, 0.00001);
  float coreH = max(t - b, 0.00001);
  float verticalWeight = clamp(coreW / (coreW + coreH), 0.28, 0.72);
  vec4 restored = horizontalFill * 0.34 + verticalFill * 0.34 + cornerFill * 0.22 + (cL + cR + cB + cT) * 0.025;
  // Light low-pass smoothing helps hide seams on flat backgrounds.
  restored = restored * 0.78 + (horizontalFill + verticalFill) * 0.11;
  restored = mix(mix(horizontalFill, verticalFill, verticalWeight), restored, 0.55);

  float coreAlpha = roundedMaskAlpha(uv, center, halfCore, cornerRadius, max(uFeather.x, uFeather.y) * 0.9);
  float alpha = max(coreAlpha, outerAlpha * 0.92);
  alpha = alpha * alpha * (3.0 - 2.0 * alpha);
  gl_FragColor = mix(original, restored, alpha);
}
