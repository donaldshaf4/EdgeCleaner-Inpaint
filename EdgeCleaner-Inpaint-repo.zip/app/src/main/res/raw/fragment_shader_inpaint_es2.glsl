#version 100
precision highp float;

uniform sampler2D uTexSampler;
uniform float uEnabled;
uniform vec4 uOuterRect;
uniform vec2 uFeather;
uniform vec2 uTexel;
uniform vec4 uSideWeights; // left, right, bottom, top
uniform vec4 uBrush0;
uniform vec4 uBrush1;
uniform vec4 uBrush2;
uniform vec4 uBrush3;
uniform vec4 uBrush4;
uniform vec4 uBrush5;
uniform vec4 uBrush6;
uniform vec4 uBrush7;
uniform vec4 uBrush8;
uniform vec4 uBrush9;
uniform vec4 uBrush10;
uniform vec4 uBrush11;
varying vec2 vTexSamplingCoord;

float ellipseMask(vec2 uv, vec4 e) {
  if (e.z <= 0.0 || e.w <= 0.0) return 0.0;
  vec2 q = (uv - e.xy) / max(e.zw, vec2(0.00001));
  float d = length(q);
  return 1.0 - smoothstep(0.88, 1.15, d);
}

float segmentMask(vec2 uv, vec4 a, vec4 b) {
  if (a.z <= 0.0 || a.w <= 0.0 || b.z <= 0.0 || b.w <= 0.0) return 0.0;
  vec2 pa = a.xy;
  vec2 pb = b.xy;
  vec2 ba = pb - pa;
  vec2 meanR = max((a.zw + b.zw) * 0.5, vec2(0.00001));
  float normalizedLength = length(ba / meanR);
  if (normalizedLength > 4.2) return 0.0; // likely a lifted/new stroke, so don't bridge it.
  float h = clamp(dot(uv - pa, ba) / max(dot(ba, ba), 0.00001), 0.0, 1.0);
  vec2 p = pa + ba * h;
  vec2 r = mix(a.zw, b.zw, h);
  vec2 q = (uv - p) / max(r, vec2(0.00001));
  float d = length(q);
  return 1.0 - smoothstep(0.90, 1.12, d);
}

float brushMask(vec2 uv) {
  float a = 0.0;
  a = max(a, ellipseMask(uv, uBrush0));
  a = max(a, ellipseMask(uv, uBrush1));
  a = max(a, ellipseMask(uv, uBrush2));
  a = max(a, ellipseMask(uv, uBrush3));
  a = max(a, ellipseMask(uv, uBrush4));
  a = max(a, ellipseMask(uv, uBrush5));
  a = max(a, ellipseMask(uv, uBrush6));
  a = max(a, ellipseMask(uv, uBrush7));
  a = max(a, ellipseMask(uv, uBrush8));
  a = max(a, ellipseMask(uv, uBrush9));
  a = max(a, ellipseMask(uv, uBrush10));
  a = max(a, ellipseMask(uv, uBrush11));

  a = max(a, segmentMask(uv, uBrush0, uBrush1));
  a = max(a, segmentMask(uv, uBrush1, uBrush2));
  a = max(a, segmentMask(uv, uBrush2, uBrush3));
  a = max(a, segmentMask(uv, uBrush3, uBrush4));
  a = max(a, segmentMask(uv, uBrush4, uBrush5));
  a = max(a, segmentMask(uv, uBrush5, uBrush6));
  a = max(a, segmentMask(uv, uBrush6, uBrush7));
  a = max(a, segmentMask(uv, uBrush7, uBrush8));
  a = max(a, segmentMask(uv, uBrush8, uBrush9));
  a = max(a, segmentMask(uv, uBrush9, uBrush10));
  a = max(a, segmentMask(uv, uBrush10, uBrush11));
  return a;
}

vec4 sampleVertical(float x, float y) {
  float sy = max(uFeather.y * 1.45, uTexel.y * 7.5);
  float sx = max(uFeather.x * 0.55, uTexel.x * 3.0);
  return (
      texture2D(uTexSampler, vec2(clamp(x - sx, 0.0, 1.0), clamp(y - sy, 0.0, 1.0))) * 0.10 +
      texture2D(uTexSampler, vec2(x, clamp(y - sy * 0.55, 0.0, 1.0))) * 0.20 +
      texture2D(uTexSampler, vec2(x, y)) * 0.40 +
      texture2D(uTexSampler, vec2(x, clamp(y + sy * 0.55, 0.0, 1.0))) * 0.20 +
      texture2D(uTexSampler, vec2(clamp(x + sx, 0.0, 1.0), clamp(y + sy, 0.0, 1.0))) * 0.10
  );
}

vec4 sampleHorizontal(float x, float y) {
  float sx = max(uFeather.x * 1.45, uTexel.x * 7.5);
  float sy = max(uFeather.y * 0.55, uTexel.y * 3.0);
  return (
      texture2D(uTexSampler, vec2(clamp(x - sx, 0.0, 1.0), clamp(y - sy, 0.0, 1.0))) * 0.10 +
      texture2D(uTexSampler, vec2(clamp(x - sx * 0.55, 0.0, 1.0), y)) * 0.20 +
      texture2D(uTexSampler, vec2(x, y)) * 0.40 +
      texture2D(uTexSampler, vec2(clamp(x + sx * 0.55, 0.0, 1.0), y)) * 0.20 +
      texture2D(uTexSampler, vec2(clamp(x + sx, 0.0, 1.0), clamp(y + sy, 0.0, 1.0))) * 0.10
  );
}

void main() {
  vec2 uv = vTexSamplingCoord;
  vec4 original = texture2D(uTexSampler, uv);
  if (uEnabled < 0.5) {
    gl_FragColor = original;
    return;
  }

  float alpha = brushMask(uv);
  if (alpha <= 0.001) {
    gl_FragColor = original;
    return;
  }

  float ol = uOuterRect.x;
  float ob = uOuterRect.y;
  float orr = uOuterRect.z;
  float ot = uOuterRect.w;
  float marginX = max(uFeather.x * 2.2, uTexel.x * 8.0);
  float marginY = max(uFeather.y * 2.2, uTexel.y * 8.0);

  float xL = clamp(ol - marginX, 0.0, 1.0);
  float xR = clamp(orr + marginX, 0.0, 1.0);
  float yB = clamp(ob - marginY, 0.0, 1.0);
  float yT = clamp(ot + marginY, 0.0, 1.0);

  vec4 cL = sampleVertical(xL, clamp(uv.y, ob, ot));
  vec4 cR = sampleVertical(xR, clamp(uv.y, ob, ot));
  vec4 cB = sampleHorizontal(clamp(uv.x, ol, orr), yB);
  vec4 cT = sampleHorizontal(clamp(uv.x, ol, orr), yT);

  vec4 w = uSideWeights * uSideWeights;
  float sum = max(0.0001, w.x + w.y + w.z + w.w);
  vec4 restored = (cL * w.x + cR * w.y + cB * w.z + cT * w.w) / sum;
  vec4 broad = (cL + cR + cB + cT) * 0.25;
  restored = mix(restored, broad, 0.34);

  alpha = alpha * alpha * (3.0 - 2.0 * alpha);
  gl_FragColor = mix(original, restored, alpha);
}
