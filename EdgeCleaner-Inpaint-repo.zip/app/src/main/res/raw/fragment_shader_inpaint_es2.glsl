#version 100
precision highp float;

uniform sampler2D uTexSampler;
uniform vec4 uCoreRect;      // left, bottom, right, top
uniform vec4 uOuterRect;     // left, bottom, right, top
uniform vec2 uFeather;       // x/y feather in normalized texture coordinates
uniform vec2 uSampleSpread;  // tangential multi-sample spread
varying vec2 vTexSamplingCoord;

float safeInv(float v) {
  return 1.0 / max(v, 0.00001);
}

vec4 sampleAvg3Horizontal(float x, float y, float spreadY) {
  return (
      texture2D(uTexSampler, vec2(x, clamp(y - spreadY, 0.0, 1.0))) +
      texture2D(uTexSampler, vec2(x, y)) +
      texture2D(uTexSampler, vec2(x, clamp(y + spreadY, 0.0, 1.0)))
  ) / 3.0;
}

vec4 sampleAvg3Vertical(float x, float y, float spreadX) {
  return (
      texture2D(uTexSampler, vec2(clamp(x - spreadX, 0.0, 1.0), y)) +
      texture2D(uTexSampler, vec2(x, y)) +
      texture2D(uTexSampler, vec2(clamp(x + spreadX, 0.0, 1.0), y))
  ) / 3.0;
}

void main() {
  vec2 uv = vTexSamplingCoord;
  vec4 original = texture2D(uTexSampler, uv);

  float coreLeft = uCoreRect.x;
  float coreBottom = uCoreRect.y;
  float coreRight = uCoreRect.z;
  float coreTop = uCoreRect.w;

  float outerLeft = uOuterRect.x;
  float outerBottom = uOuterRect.y;
  float outerRight = uOuterRect.z;
  float outerTop = uOuterRect.w;

  // Outside the softened edit area -> untouched.
  if (uv.x < outerLeft || uv.x > outerRight || uv.y < outerBottom || uv.y > outerTop) {
    gl_FragColor = original;
    return;
  }

  float dl = max(uv.x - coreLeft, 0.0);
  float dr = max(coreRight - uv.x, 0.0);
  float db = max(uv.y - coreBottom, 0.0);
  float dt = max(coreTop - uv.y, 0.0);

  // Use samples from outside the outer rect, not directly from the immediate mask border.
  vec2 pL = vec2(clamp(outerLeft - max(dl, uFeather.x), 0.0, 1.0), uv.y);
  vec2 pR = vec2(clamp(outerRight + max(dr, uFeather.x), 0.0, 1.0), uv.y);
  vec2 pB = vec2(uv.x, clamp(outerBottom - max(db, uFeather.y), 0.0, 1.0));
  vec2 pT = vec2(uv.x, clamp(outerTop + max(dt, uFeather.y), 0.0, 1.0));

  vec4 cL = sampleAvg3Horizontal(pL.x, pL.y, uSampleSpread.y);
  vec4 cR = sampleAvg3Horizontal(pR.x, pR.y, uSampleSpread.y);
  vec4 cB = sampleAvg3Vertical(pB.x, pB.y, uSampleSpread.x);
  vec4 cT = sampleAvg3Vertical(pT.x, pT.y, uSampleSpread.x);

  float wL = safeInv(dl + uFeather.x);
  float wR = safeInv(dr + uFeather.x);
  float wB = safeInv(db + uFeather.y);
  float wT = safeInv(dt + uFeather.y);
  vec4 restored = (cL * wL + cR * wR + cB * wB + cT * wT) / (wL + wR + wB + wT);

  // If we're inside the core rect, use restored content fully.
  bool insideCore = (uv.x >= coreLeft && uv.x <= coreRight && uv.y >= coreBottom && uv.y <= coreTop);
  if (insideCore) {
    gl_FragColor = restored;
    return;
  }

  // In the ring between outer rect and core rect, softly transition from original -> restored.
  float ringDX = 0.0;
  if (uv.x < coreLeft) ringDX = coreLeft - uv.x;
  else if (uv.x > coreRight) ringDX = uv.x - coreRight;

  float ringDY = 0.0;
  if (uv.y < coreBottom) ringDY = coreBottom - uv.y;
  else if (uv.y > coreTop) ringDY = uv.y - coreTop;

  float ringDistance = max(ringDX, ringDY);
  float maxRingX = max(coreLeft - outerLeft, outerRight - coreRight);
  float maxRingY = max(coreBottom - outerBottom, outerTop - coreTop);
  float maxRing = max(maxRingX, maxRingY);
  float t = 1.0 - smoothstep(0.0, max(maxRing, 0.00001), ringDistance);

  // Keep a little original contribution in the transition ring for a more natural edge.
  float alpha = 0.2 + 0.8 * t;
  gl_FragColor = mix(original, restored, alpha);
}
