package com.edgecleaner.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.RectF;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.OptIn;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;

import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.photo.Photo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_IMAGE = 1001;
    private static final int REQ_VIDEO = 1002;

    private Uri selectedUri;
    private boolean selectedVideo;
    private boolean openCvReady;
    private boolean darkTheme;

    private FrameLayout previewFrame;

    private ImageView imagePreview;
    private VideoView videoPreview;
    private MaskSelectionView maskView;
    private SeekBar radiusSeek;
    private TextView radiusText;
    private SeekBar brushSeek;
    private TextView brushText;
    private SeekBar eraserSeek;
    private TextView eraserText;
    private SeekBar smoothSeek;
    private TextView smoothText;
    private TextView statusText;
    private ProgressBar progressBar;
    private Button processButton;
    private Button resetMaskButton;
    private Button toolModeButton;
    private Button autoDetectButton;
    private int brushSizeDp = 18;
    private int eraserSizeDp = 7;

    private LinearLayout videoControls;
    private SeekBar timelineSeek;
    private TextView timeText;
    private TextView keyframeText;
    private Button playPauseButton;
    private Button addKeyframeButton;
    private Button disableMaskButton;
    private Button clearKeyframesButton;
    private int videoDurationMs;
    private boolean timelineTracking;
    private final ArrayList<MaskKeyframe> keyframes = new ArrayList<>();
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable timelineTicker = new Runnable() {
        @Override public void run() {
            if (selectedVideo && videoPreview != null && videoPreview.getVisibility() == View.VISIBLE) {
                if (!timelineTracking && videoDurationMs > 0) {
                    int pos = Math.max(0, videoPreview.getCurrentPosition());
                    timelineSeek.setProgress(Math.min(1000, Math.round(pos * 1000f / videoDurationMs)));
                    updateTimeText(pos);
                    if (videoPreview.isPlaying()) showMaskForPosition(pos);
                }
                playPauseButton.setText(videoPreview.isPlaying() ? "Пауза" : "Продолжить");
            }
            uiHandler.postDelayed(this, 180);
        }
    };

    private Transformer transformer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        darkTheme = getSharedPreferences("edgecleaner_settings", MODE_PRIVATE)
                .getBoolean("dark_theme", false);
        setTheme(darkTheme ? R.style.AppThemeDark : R.style.AppTheme);
        super.onCreate(savedInstanceState);
        openCvReady = OpenCVLoader.initLocal();
        setContentView(buildUi());
        if (!openCvReady) {
            statusText.setText("OpenCV не загрузился. Обработка фото будет недоступна.");
        }
    }

    private View buildUi() {
        int pad = dp(16);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(darkTheme ? 0xFF0E1116 : 0xFFF7F7F7);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(darkTheme ? 0xFF0E1116 : 0xFFF7F7F7);
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        ImageView brandLogo = new ImageView(this);
        brandLogo.setImageResource(R.drawable.edgecleaner_logo);
        brandLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(-1, dp(132));
        logoLp.bottomMargin = dp(4);
        root.addView(brandLogo, logoLp);

        TextView title = new TextView(this);
        title.setText("EdgeCleaner Inpaint Pro");
        title.setTextSize(26f);
        title.setTextColor(darkTheme ? 0xFFF3F6FA : 0xFF243447);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView intro = new TextView(this);
        intro.setText("PRO: поставьте видео на паузу и закрасьте watermark пальцем как кистью. Добавьте точку маски. Если watermark меняется — перемотайте и нарисуйте новую маску. Обрабатывается только закрашенная форма, без прямоугольного шва.");
        intro.setTextSize(14f);
        intro.setTextColor(darkTheme ? 0xFFB9C2CF : 0xFF5D6778);
        intro.setPadding(0, dp(8), 0, dp(12));
        root.addView(intro, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout themeRow = new LinearLayout(this);
        themeRow.setOrientation(LinearLayout.HORIZONTAL);
        themeRow.setGravity(Gravity.CENTER_VERTICAL);
        themeRow.setPadding(dp(12), dp(4), dp(8), dp(8));
        TextView themeLabel = new TextView(this);
        themeLabel.setText("Оформление");
        themeLabel.setTextSize(15f);
        themeLabel.setTextColor(darkTheme ? 0xFFE8EDF4 : 0xFF334155);
        themeRow.addView(themeLabel, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch themeSwitch = new Switch(this);
        themeSwitch.setText(darkTheme ? "Тёмная" : "Светлая");
        themeSwitch.setChecked(darkTheme);
        themeSwitch.setOnCheckedChangeListener((buttonView, checked) -> {
            getSharedPreferences("edgecleaner_settings", MODE_PRIVATE)
                    .edit().putBoolean("dark_theme", checked).apply();
            recreate();
        });
        themeRow.addView(themeSwitch, new LinearLayout.LayoutParams(-2, -2));
        root.addView(themeRow, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout pickRow = new LinearLayout(this);
        pickRow.setOrientation(LinearLayout.HORIZONTAL);

        Button pickImage = new Button(this);
        pickImage.setAllCaps(false);
        pickImage.setText("Выбрать фото");
        pickImage.setOnClickListener(v -> pickMedia(false));
        pickRow.addView(pickImage, new LinearLayout.LayoutParams(0, -2, 1f));

        Button pickVideo = new Button(this);
        pickVideo.setAllCaps(false);
        pickVideo.setText("Выбрать видео");
        pickVideo.setOnClickListener(v -> pickMedia(true));
        LinearLayout.LayoutParams videoLp = new LinearLayout.LayoutParams(0, -2, 1f);
        videoLp.setMarginStart(dp(8));
        pickRow.addView(pickVideo, videoLp);
        root.addView(pickRow, new LinearLayout.LayoutParams(-1, -2));

        previewFrame = new FrameLayout(this);
        previewFrame.setBackgroundColor(Color.BLACK);
        previewFrame.setPadding(dp(0), dp(0), dp(0), dp(0));
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(-1, dp(330));
        previewLp.topMargin = dp(10);
        root.addView(previewFrame, previewLp);

        imagePreview = new ImageView(this);
        imagePreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imagePreview.setVisibility(View.GONE);
        previewFrame.addView(imagePreview, new FrameLayout.LayoutParams(-1, -1));

        videoPreview = new VideoView(this);
        videoPreview.setVisibility(View.GONE);
        videoPreview.setOnPreparedListener(mp -> {
            mp.setLooping(false);
            adjustPreviewHeight(mp.getVideoWidth(), mp.getVideoHeight());
            maskView.setContentSize(mp.getVideoWidth(), mp.getVideoHeight());
            maskView.bringToFront();
            maskView.setClickable(true);
            videoDurationMs = Math.max(1, mp.getDuration());
            timelineSeek.setProgress(0);
            videoPreview.seekTo(0);
            videoPreview.pause();
            updateTimeText(0);
            playPauseButton.setText("Продолжить");
            setVideoControlsEnabled(true);
            updateVideoLoupeFrame(0);
            statusText.setText("Видео готово. Поставьте паузу, закрасьте watermark кистью и нажмите «Добавить маску». ");
        });
        videoPreview.setOnCompletionListener(mp -> {
            playPauseButton.setText("Продолжить");
            updateTimeText(videoDurationMs);
        });
        FrameLayout.LayoutParams videoPreviewLp = new FrameLayout.LayoutParams(-1, -1);
        videoPreviewLp.gravity = Gravity.CENTER;
        previewFrame.addView(videoPreview, videoPreviewLp);

        maskView = new MaskSelectionView(this);
        maskView.setBrushSizeDp(brushSizeDp);
        maskView.setEraseBrushSizeDp(eraserSizeDp);
        maskView.setVisibility(View.GONE);
        maskView.setOnBrushStartListener(() -> {
            if (selectedVideo) {
                if (videoPreview.isPlaying()) {
                    videoPreview.pause();
                    if (playPauseButton != null) playPauseButton.setText("Продолжить");
                }
                updateVideoLoupeFrame(videoPreview.getCurrentPosition());
            }
        });
        previewFrame.addView(maskView, new FrameLayout.LayoutParams(-1, -1));

        videoControls = new LinearLayout(this);
        videoControls.setOrientation(LinearLayout.VERTICAL);
        videoControls.setVisibility(View.GONE);
        LinearLayout.LayoutParams controlsLp = new LinearLayout.LayoutParams(-1, -2);
        controlsLp.topMargin = dp(8);
        root.addView(videoControls, controlsLp);

        timeText = new TextView(this);
        timeText.setGravity(Gravity.CENTER_HORIZONTAL);
        timeText.setText("00:00.000 / 00:00.000");
        videoControls.addView(timeText, new LinearLayout.LayoutParams(-1, -2));

        timelineSeek = new SeekBar(this);
        timelineSeek.setMax(1000);
        timelineSeek.setEnabled(false);
        timelineSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || videoDurationMs <= 0) return;
                int position = Math.round(videoDurationMs * progress / 1000f);
                videoPreview.seekTo(position);
                updateTimeText(position);
                showMaskForPosition(position);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {
                timelineTracking = true;
                if (videoPreview.isPlaying()) videoPreview.pause();
                playPauseButton.setText("Продолжить");
            }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                timelineTracking = false;
                int position = Math.round(videoDurationMs * seekBar.getProgress() / 1000f);
                videoPreview.seekTo(position);
                showMaskForPosition(position);
                updateVideoLoupeFrame(position);
            }
        });
        videoControls.addView(timelineSeek, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout transportRow = new LinearLayout(this);
        transportRow.setOrientation(LinearLayout.HORIZONTAL);
        playPauseButton = new Button(this);
        playPauseButton.setAllCaps(false);
        playPauseButton.setText("Продолжить");
        playPauseButton.setEnabled(false);
        playPauseButton.setOnClickListener(v -> togglePlayback());
        transportRow.addView(playPauseButton, new LinearLayout.LayoutParams(0, -2, 1f));

        addKeyframeButton = new Button(this);
        addKeyframeButton.setAllCaps(false);
        addKeyframeButton.setText("Добавить маску");
        addKeyframeButton.setEnabled(false);
        addKeyframeButton.setOnClickListener(v -> addMaskKeyframe());
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(0, -2, 1f);
        addLp.setMarginStart(dp(8));
        transportRow.addView(addKeyframeButton, addLp);
        videoControls.addView(transportRow, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout maskStateRow = new LinearLayout(this);
        maskStateRow.setOrientation(LinearLayout.HORIZONTAL);
        disableMaskButton = new Button(this);
        disableMaskButton.setAllCaps(false);
        disableMaskButton.setText("Без маски отсюда");
        disableMaskButton.setEnabled(false);
        disableMaskButton.setOnClickListener(v -> addDisabledKeyframe());
        maskStateRow.addView(disableMaskButton, new LinearLayout.LayoutParams(0, -2, 1f));

        clearKeyframesButton = new Button(this);
        clearKeyframesButton.setAllCaps(false);
        clearKeyframesButton.setText("Очистить точки");
        clearKeyframesButton.setEnabled(false);
        clearKeyframesButton.setOnClickListener(v -> {
            keyframes.clear();
            updateKeyframeText();
            maskView.clearMask();
            maskView.setEraseMode(false);
            refreshToolUi();
            Toast.makeText(this, "Все точки маски удалены", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(0, -2, 1f);
        clearLp.setMarginStart(dp(8));
        maskStateRow.addView(clearKeyframesButton, clearLp);
        videoControls.addView(maskStateRow, new LinearLayout.LayoutParams(-1, -2));

        keyframeText = new TextView(this);
        keyframeText.setText("Точки маски: 0");
        keyframeText.setTextSize(13f);
        keyframeText.setPadding(0, dp(4), 0, 0);
        videoControls.addView(keyframeText, new LinearLayout.LayoutParams(-1, -2));

        TextView maskHint = new TextView(this);
        maskHint.setText("Проведите пальцем по watermark — видео само встанет на паузу, а над пальцем появится лупа. Затем нажмите «Добавить маску». Для новой позиции watermark добавьте новую точку на нужном кадре.");
        maskHint.setTextSize(13f);
        maskHint.setPadding(0, dp(8), 0, dp(2));
        root.addView(maskHint, new LinearLayout.LayoutParams(-1, -2));

        resetMaskButton = new Button(this);
        resetMaskButton.setAllCaps(false);
        resetMaskButton.setText("Очистить текущую маску");
        resetMaskButton.setEnabled(false);
        resetMaskButton.setOnClickListener(v -> {
            maskView.clearMask();
            maskView.setEraseMode(false);
            refreshToolUi();
        });
        root.addView(resetMaskButton, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout toolRow = new LinearLayout(this);
        toolRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams toolRowLp = new LinearLayout.LayoutParams(-1, -2);
        toolRowLp.topMargin = dp(6);
        root.addView(toolRow, toolRowLp);

        toolModeButton = new Button(this);
        toolModeButton.setAllCaps(false);
        toolModeButton.setText("Режим: кисть");
        toolModeButton.setEnabled(false);
        toolModeButton.setOnClickListener(v -> {
            boolean erase = !maskView.isEraseMode();
            maskView.setEraseMode(erase);
            refreshToolUi();
            statusText.setText(erase
                    ? "Ластик включён. Он стирает только то место, куда вы навели."
                    : "Кисть включена. Закрашивайте только watermark тонкой полосой.");
        });
        toolRow.addView(toolModeButton, new LinearLayout.LayoutParams(0, -2, 1f));

        autoDetectButton = new Button(this);
        autoDetectButton.setAllCaps(false);
        autoDetectButton.setText("Авто watermark");
        autoDetectButton.setEnabled(false);
        autoDetectButton.setOnClickListener(v -> autoDetectWatermark());
        LinearLayout.LayoutParams autoLp = new LinearLayout.LayoutParams(0, -2, 1f);
        autoLp.setMarginStart(dp(8));
        toolRow.addView(autoDetectButton, autoLp);

        TextView toolHint = new TextView(this);
        toolHint.setText("Кисть — закрашивает. Ластик — подтирает только лишнее. «Авто watermark» ищет похожий логотип/надпись на текущем кадре, после чего маску можно подправить вручную.");
        toolHint.setTextSize(13f);
        toolHint.setTextColor(darkTheme ? 0xFFB9C2CF : 0xFF5D6778);
        toolHint.setPadding(0, dp(6), 0, dp(2));
        root.addView(toolHint, new LinearLayout.LayoutParams(-1, -2));

        brushText = new TextView(this);
        brushText.setText("Размер кисти: " + brushSizeDp);
        brushText.setPadding(0, dp(8), 0, dp(2));
        root.addView(brushText);

        brushSeek = new SeekBar(this);
        brushSeek.setMax(56); // 4..60 dp
        brushSeek.setProgress(brushSizeDp - 4);
        brushSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                brushSizeDp = progress + 4;
                brushText.setText("Размер кисти: " + brushSizeDp);
                maskView.setBrushSizeDp(brushSizeDp);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        root.addView(brushSeek, new LinearLayout.LayoutParams(-1, -2));

        eraserText = new TextView(this);
        eraserText.setText("Размер ластика: " + eraserSizeDp);
        eraserText.setPadding(0, dp(6), 0, dp(2));
        root.addView(eraserText);

        eraserSeek = new SeekBar(this);
        eraserSeek.setMax(38); // 2..40 dp
        eraserSeek.setProgress(eraserSizeDp - 2);
        eraserSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                eraserSizeDp = progress + 2;
                eraserText.setText("Размер ластика: " + eraserSizeDp);
                maskView.setEraseBrushSizeDp(eraserSizeDp);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        root.addView(eraserSeek, new LinearLayout.LayoutParams(-1, -2));

        radiusText = new TextView(this);
        radiusText.setText("Мягкость восстановления: 5 px");
        radiusText.setPadding(0, dp(8), 0, dp(2));
        root.addView(radiusText);

        radiusSeek = new SeekBar(this);
        radiusSeek.setMax(21); // 3..24 px
        radiusSeek.setProgress(2); // 5 px
        radiusSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                radiusText.setText("Мягкость восстановления: " + (progress + 3) + " px");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        root.addView(radiusSeek, new LinearLayout.LayoutParams(-1, -2));

        smoothText = new TextView(this);
        smoothText.setText("Сглаживание видео: 25%");
        smoothText.setTextColor(darkTheme ? 0xFFB9C2CF : 0xFF5D6778);
        smoothText.setPadding(0, dp(8), 0, dp(2));
        root.addView(smoothText);

        smoothSeek = new SeekBar(this);
        smoothSeek.setMax(100);
        smoothSeek.setProgress(25);
        smoothSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                smoothText.setText("Сглаживание видео: " + progress + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        root.addView(smoothSeek, new LinearLayout.LayoutParams(-1, -2));

        processButton = new Button(this);
        processButton.setAllCaps(false);
        processButton.setText("Восстановить");
        processButton.setEnabled(false);
        processButton.setOnClickListener(v -> processSelected());
        LinearLayout.LayoutParams processLp = new LinearLayout.LayoutParams(-1, -2);
        processLp.topMargin = dp(6);
        root.addView(processButton, processLp);

        progressBar = new ProgressBar(this);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-2, -2);
        progressLp.gravity = Gravity.CENTER_HORIZONTAL;
        progressLp.topMargin = dp(6);
        root.addView(progressBar, progressLp);

        statusText = new TextView(this);
        statusText.setText("Выберите фото или видео.");
        statusText.setGravity(Gravity.CENTER_HORIZONTAL);
        statusText.setPadding(0, dp(6), 0, dp(12));
        root.addView(statusText, new LinearLayout.LayoutParams(-1, -2));

        uiHandler.post(timelineTicker);
        return scroll;
    }

    private void pickMedia(boolean video) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(video ? "video/*" : "image/*");
        startActivityForResult(intent, video ? REQ_VIDEO : REQ_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;

        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(
                    uri,
                    data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
        } catch (Exception ignored) {
        }
        loadMediaIntoEditor(uri, requestCode == REQ_VIDEO, false);
    }

    private void loadMediaIntoEditor(Uri uri, boolean video, boolean fromProcessedResult) {
        selectedUri = uri;
        selectedVideo = video;
        keyframes.clear();
        videoDurationMs = 0;
        updateKeyframeText();
        processButton.setEnabled(selectedVideo || openCvReady);
        resetMaskButton.setEnabled(true);
        if (toolModeButton != null) toolModeButton.setEnabled(true);
        if (autoDetectButton != null) autoDetectButton.setEnabled(true);
        maskView.setVisibility(View.VISIBLE);
        maskView.bringToFront();
        maskView.setClickable(true);
        maskView.clearMask();
        maskView.setEraseMode(false);
        refreshToolUi();

        if (selectedVideo) {
            imagePreview.setImageDrawable(null);
            imagePreview.setVisibility(View.GONE);
            videoPreview.stopPlayback();
            videoPreview.setVisibility(View.VISIBLE);
            maskView.setPreviewBitmap(null);
            videoControls.setVisibility(View.VISIBLE);
            setVideoControlsEnabled(false);
            videoPreview.setVideoURI(selectedUri);
            statusText.setText(fromProcessedResult
                    ? "Результат загружен. Можно сразу сделать ещё один проход по этому видео."
                    : "Загрузка видео…");
        } else {
            videoPreview.stopPlayback();
            videoPreview.setVisibility(View.GONE);
            videoControls.setVisibility(View.GONE);
            imagePreview.setVisibility(View.VISIBLE);
            Bitmap preview = loadPreviewBitmap(selectedUri, 1800);
            imagePreview.setImageBitmap(preview);
            maskView.setPreviewBitmap(preview);
            if (preview != null) {
                adjustPreviewHeight(preview.getWidth(), preview.getHeight());
                maskView.setContentSize(preview.getWidth(), preview.getHeight());
            }
            statusText.setText(openCvReady
                    ? (fromProcessedResult
                        ? "Результат загружен. Можно обработать фото ещё раз."
                        : "Фото выбрано. Закрасьте водяной знак кистью.")
                    : "Фото выбрано, но OpenCV не загрузился.");
        }
    }

    private void refreshToolUi() {
        boolean erase = maskView != null && maskView.isEraseMode();
        if (toolModeButton != null) toolModeButton.setText(erase ? "Режим: ластик" : "Режим: кисть");
        if (brushText != null) brushText.setText("Размер кисти: " + brushSizeDp);
        if (eraserText != null) eraserText.setText("Размер ластика: " + eraserSizeDp);
        if (maskView != null) {
            maskView.setBrushSizeDp(brushSizeDp);
            maskView.setEraseBrushSizeDp(eraserSizeDp);
        }
    }

    private void autoDetectWatermark() {
        if (selectedUri == null) return;
        Bitmap preview = maskView.getPreviewBitmap();
        if (preview == null && selectedVideo) {
            preview = loadVideoFrameBitmap(selectedUri, Math.max(0, videoPreview.getCurrentPosition()), 1280);
            if (preview != null) maskView.setPreviewBitmap(preview);
        }
        if (preview == null && !selectedVideo) {
            preview = loadPreviewBitmap(selectedUri, 1800);
            if (preview != null) maskView.setPreviewBitmap(preview);
        }
        if (preview == null) {
            Toast.makeText(this, "Не удалось получить кадр для автоопределения.", Toast.LENGTH_LONG).show();
            return;
        }
        ArrayList<MaskCircle> detected = detectWatermarkMask(preview);
        if (detected.isEmpty()) {
            Toast.makeText(this, "Авто watermark ничего уверенно не нашёл. Попробуйте закрасить вручную.", Toast.LENGTH_LONG).show();
            return;
        }
        maskView.setNormalizedCircles(detected);
        maskView.setEraseMode(false);
        refreshToolUi();
        statusText.setText("Автомаска поставлена. При необходимости подправьте кистью или ластиком.");
    }

    private ArrayList<MaskCircle> detectWatermarkMask(Bitmap preview) {
        ArrayList<MaskCircle> out = new ArrayList<>();
        if (!openCvReady || preview == null) return out;

        Mat rgba = new Mat();
        Mat gray = new Mat();
        Mat blur = new Mat();
        Mat detail = new Mat();
        Mat bright = new Mat();
        Mat dark = new Mat();
        Mat contrast = new Mat();
        Mat candidate = new Mat();
        Mat kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(3, 3));
        try {
            Utils.bitmapToMat(preview, rgba);
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY);

            int fullW = gray.cols();
            int fullH = gray.rows();
            int roiW = Math.min(fullW, Math.max(40, Math.round(fullW * 0.36f)));
            int roiH = Math.min(fullH, Math.max(28, Math.round(fullH * 0.25f)));
            Rect[] rois = new Rect[]{
                    new Rect(0, 0, roiW, roiH),
                    new Rect(Math.max(0, fullW - roiW), 0, roiW, roiH),
                    new Rect(0, Math.max(0, fullH - roiH), roiW, roiH),
                    new Rect(Math.max(0, fullW - roiW), Math.max(0, fullH - roiH), roiW, roiH)
            };

            double bestScore = 0.0;
            Rect bestRect = null;

            for (Rect roiRect : rois) {
                Mat roi = new Mat(gray, roiRect);
                Imgproc.GaussianBlur(roi, blur, new Size(0, 0), 4.2);
                Core.absdiff(roi, blur, detail);
                Imgproc.threshold(roi, bright, 178, 255, Imgproc.THRESH_BINARY);
                Imgproc.threshold(roi, dark, 84, 255, Imgproc.THRESH_BINARY_INV);
                Imgproc.threshold(detail, contrast, 24, 255, Imgproc.THRESH_BINARY);
                Core.bitwise_or(bright, dark, candidate);
                Core.bitwise_and(candidate, contrast, candidate);
                Imgproc.morphologyEx(candidate, candidate, Imgproc.MORPH_CLOSE, kernel);
                Imgproc.dilate(candidate, candidate, kernel, new Point(-1, -1), 1);

                List<MatOfPoint> contours = new ArrayList<>();
                Imgproc.findContours(candidate, contours, new Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);
                for (MatOfPoint contour : contours) {
                    Rect b = Imgproc.boundingRect(contour);
                    double area = b.width * b.height;
                    double roiArea = roiRect.width * roiRect.height;
                    if (area < roiArea * 0.0035 || area > roiArea * 0.30) continue;
                    float aspect = b.width / (float) Math.max(1, b.height);
                    if (aspect < 0.7f || aspect > 10f) continue;

                    float cx = b.x + b.width * 0.5f;
                    float cy = b.y + b.height * 0.5f;
                    float cornerX = roiRect.x == 0 ? 0f : roiRect.width;
                    float cornerY = roiRect.y == 0 ? 0f : roiRect.height;
                    double cornerDist = Math.hypot(cx - cornerX, cy - cornerY);
                    double maxDist = Math.hypot(roiRect.width, roiRect.height);
                    double cornerBonus = 1.0 - Math.min(1.0, cornerDist / Math.max(1.0, maxDist));
                    double score = area * (0.9 + cornerBonus * 1.1);
                    if (score > bestScore) {
                        bestScore = score;
                        bestRect = new Rect(roiRect.x + b.x, roiRect.y + b.y, b.width, b.height);
                    }
                }
                roi.release();
            }

            if (bestRect != null) {
                int padX = Math.max(4, Math.round(bestRect.width * 0.12f));
                int padY = Math.max(4, Math.round(bestRect.height * 0.18f));
                int left = clamp(bestRect.x - padX, 0, fullW - 1);
                int top = clamp(bestRect.y - padY, 0, fullH - 1);
                int right = clamp(bestRect.x + bestRect.width + padX, 1, fullW);
                int bottom = clamp(bestRect.y + bestRect.height + padY, 1, fullH);
                out = buildStripMask(left, top, right, bottom, fullW, fullH);
            }
        } catch (Exception ignored) {
            out.clear();
        } finally {
            kernel.release();
            candidate.release();
            contrast.release();
            dark.release();
            bright.release();
            detail.release();
            blur.release();
            gray.release();
            rgba.release();
        }
        return out;
    }

    private ArrayList<MaskCircle> buildStripMask(int left, int top, int right, int bottom, int imgW, int imgH) {
        ArrayList<MaskCircle> out = new ArrayList<>();
        int width = Math.max(1, right - left);
        int height = Math.max(1, bottom - top);
        float brushRadiusPx = Math.max(6f, dp(Math.round(maskView.getBrushSizeDp())) * 0.5f);
        float stepX = Math.max(brushRadiusPx * 1.05f, width / 7f);
        int rows = Math.max(1, Math.min(3, Math.round(height / Math.max(10f, brushRadiusPx * 1.2f))));
        float rowStep = rows <= 1 ? 0f : height / (float) (rows - 1);
        for (int r = 0; r < rows; r++) {
            float y = top + (rows == 1 ? height * 0.5f : r * rowStep);
            boolean reverse = (r % 2 == 1);
            int points = Math.max(2, Math.min(8, Math.round(width / Math.max(10f, stepX)) + 1));
            for (int i = 0; i < points; i++) {
                int idx = reverse ? (points - 1 - i) : i;
                float x = left + width * (points == 1 ? 0.5f : idx / (float) (points - 1));
                float nx = Math.max(0f, Math.min(1f, x / Math.max(1f, imgW)));
                float ny = Math.max(0f, Math.min(1f, y / Math.max(1f, imgH)));
                float rx = (brushRadiusPx / Math.max(1f, imgW)) * 0.95f;
                float ry = (brushRadiusPx / Math.max(1f, imgH)) * 0.95f;
                out.add(new MaskCircle(nx, ny, rx, ry));
                if (out.size() >= 18) return out;
            }
        }
        return out;
    }

    private void processSelected() {
        if (selectedUri == null) return;
        int radius = radiusSeek.getProgress() + 3;

        if (selectedVideo) {
            if (keyframes.isEmpty()) {
                Bitmap mask = maskView.getMaskBitmapCopy();
                if (mask == null) {
                    Toast.makeText(this, "Сначала закрасьте watermark кистью или добавьте точку маски.", Toast.LENGTH_LONG).show();
                    return;
                }
                keyframes.add(new MaskKeyframe(videoPreview.getCurrentPosition() * 1000L, mask, true));
                sortKeyframes();
                updateKeyframeText();
            }
            setBusy(true, "Точное восстановление видео по растровой маске…");
            float smoothStrength = smoothSeek.getProgress() / 100f;
            processVideo(selectedUri, new ArrayList<>(keyframes), radius, smoothStrength);
            return;
        }

        Bitmap mask = maskView.getMaskBitmapCopy();
        if (mask == null) {
            Toast.makeText(this, "Сначала закрасьте водяной знак кистью.", Toast.LENGTH_LONG).show();
            return;
        }
        setBusy(true, "Восстановление фото по точной маске…");
        new Thread(() -> processImage(selectedUri, mask, radius)).start();
    }

    private void processImage(Uri uri, Bitmap rasterMask, int radius) {
        Bitmap source = null;
        Bitmap result = null;
        Bitmap scaledMask = null;
        Mat rgba = null;
        Mat rgb = null;
        Mat maskRgba = null;
        Mat mask = null;
        Mat restored = null;
        Mat outRgba = null;
        try {
            if (!openCvReady) throw new IOException("OpenCV не инициализирован");
            source = decodeBitmap(uri);
            if (source == null) throw new IOException("Не удалось декодировать изображение");

            int w = source.getWidth();
            int h = source.getHeight();

            rgba = new Mat();
            Utils.bitmapToMat(source, rgba);
            rgb = new Mat();
            Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB);

            scaledMask = Bitmap.createScaledBitmap(rasterMask, w, h, true);
            maskRgba = new Mat();
            Utils.bitmapToMat(scaledMask, maskRgba);
            mask = new Mat();
            Imgproc.cvtColor(maskRgba, mask, Imgproc.COLOR_RGBA2GRAY);
            Imgproc.threshold(mask, mask, 8, 255, Imgproc.THRESH_BINARY);

            // Keep the exact painted shape. A tiny dilation only closes sub-pixel gaps from scaling.
            if (radius > 5) {
                Mat kernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, new Size(3, 3));
                Imgproc.dilate(mask, mask, kernel, new Point(-1, -1), 1);
                kernel.release();
            }

            restored = new Mat();
            Photo.inpaint(rgb, mask, restored, Math.max(2, Math.min(radius, 12)), Photo.INPAINT_TELEA);

            outRgba = new Mat();
            Imgproc.cvtColor(restored, outRgba, Imgproc.COLOR_RGB2RGBA);
            result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Utils.matToBitmap(outRgba, result);

            Uri saved = saveBitmap(result);
            Uri finalSaved = saved;
            runOnUiThread(() -> {
                setBusy(false, finalSaved != null ? "Готово: фото восстановлено и сохранено." : "Восстановлено, но не удалось сохранить файл.");
                if (finalSaved != null) loadMediaIntoEditor(finalSaved, false, true);
            });
        } catch (Exception e) {
            String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            runOnUiThread(() -> setBusy(false, "Ошибка фото: " + msg));
        } finally {
            if (outRgba != null) outRgba.release();
            if (restored != null) restored.release();
            if (mask != null) mask.release();
            if (maskRgba != null) maskRgba.release();
            if (rgb != null) rgb.release();
            if (rgba != null) rgba.release();
            if (scaledMask != null && scaledMask != rasterMask && !scaledMask.isRecycled()) scaledMask.recycle();
            if (rasterMask != null && !rasterMask.isRecycled()) rasterMask.recycle();
            if (result != null && result != source && !result.isRecycled()) result.recycle();
            if (source != null && !source.isRecycled()) source.recycle();
        }
    }

    private Bitmap decodeBitmap(Uri uri) throws IOException {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.Source src = ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(src, (decoder, info, s) -> decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE));
        }
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            return BitmapFactory.decodeStream(in);
        }
    }

    private Bitmap loadPreviewBitmap(Uri uri, int maxDim) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            int sample = 1;
            while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > maxDim) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = Math.max(1, sample);
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                return BitmapFactory.decodeStream(in, null, opts);
            }
        } catch (Exception e) {
            return null;
        }
    }

    private void adjustPreviewHeight(int mediaWidth, int mediaHeight) {
        if (previewFrame == null || mediaWidth <= 0 || mediaHeight <= 0) return;
        previewFrame.post(() -> {
            int availableWidth = previewFrame.getWidth();
            if (availableWidth <= 0) {
                availableWidth = getResources().getDisplayMetrics().widthPixels - dp(32);
            }
            float aspect = mediaWidth / (float) mediaHeight;
            int desired = Math.round(availableWidth / Math.max(0.20f, aspect));
            int minHeight = dp(300);
            int maxHeight = dp(560);
            int target = Math.max(minHeight, Math.min(maxHeight, desired));
            android.view.ViewGroup.LayoutParams lp = previewFrame.getLayoutParams();
            if (lp != null && lp.height != target) {
                lp.height = target;
                previewFrame.setLayoutParams(lp);
            }
        });
    }

    private Bitmap loadVideoFrameBitmap(Uri uri, long positionMs, int maxDim) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, uri);
            Bitmap frame = retriever.getFrameAtTime(positionMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST);
            if (frame == null) return null;
            int w = frame.getWidth();
            int h = frame.getHeight();
            int maxSide = Math.max(w, h);
            if (maxSide > maxDim) {
                float scale = maxDim / (float) maxSide;
                Bitmap scaled = Bitmap.createScaledBitmap(frame, Math.round(w * scale), Math.round(h * scale), true);
                if (scaled != frame) frame.recycle();
                frame = scaled;
            }
            return frame;
        } catch (Exception e) {
            return null;
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
        }
    }

    private void updateVideoLoupeFrame(int positionMs) {
        if (!selectedVideo || selectedUri == null) return;
        final Uri uri = selectedUri;
        final int pos = Math.max(0, positionMs);
        new Thread(() -> {
            Bitmap frame = loadVideoFrameBitmap(uri, pos, 1280);
            if (frame != null) {
                runOnUiThread(() -> {
                    if (selectedVideo && uri.equals(selectedUri)) maskView.setPreviewBitmap(frame);
                });
            }
        }).start();
    }

    private Uri saveBitmap(Bitmap bitmap) throws IOException {
        String name = "EdgeCleaner_Inpaint_" + timestamp() + ".jpg";
        ContentResolver resolver = getContentResolver();

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/EdgeCleaner");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri out = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (out == null) throw new IOException("MediaStore insert failed");
            try (OutputStream os = resolver.openOutputStream(out)) {
                if (os == null || !bitmap.compress(Bitmap.CompressFormat.JPEG, 95, os)) {
                    throw new IOException("Не удалось записать JPEG");
                }
            }
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(out, values, null, null);
            return out;
        }

        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "EdgeCleaner");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Не удалось создать папку");
        File out = new File(dir, name);
        try (OutputStream os = new FileOutputStream(out)) {
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 95, os)) throw new IOException("Не удалось записать JPEG");
        }
        return Uri.fromFile(out);
    }

    @OptIn(markerClass = UnstableApi.class)
    private void processVideo(Uri uri, List<MaskKeyframe> masks, int radius, float smoothStrength) {
        Effect restore = new VideoInpaintEffect(masks, radius, smoothStrength);
        EditedMediaItem item = new EditedMediaItem.Builder(MediaItem.fromUri(uri))
                .setEffects(new Effects(Collections.emptyList(), Collections.singletonList(restore)))
                .build();

        File temp = new File(getCacheDir(), "edgecleaner_inpaint_" + timestamp() + ".mp4");
        if (temp.exists()) temp.delete();

        transformer = new Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(new Transformer.Listener() {
                    @Override
                    public void onCompleted(Composition composition, ExportResult exportResult) {
                        transformer = null;
                        new Thread(() -> {
                            try {
                                Uri saved = publishVideo(temp);
                                runOnUiThread(() -> {
                                    setBusy(false, saved != null ? "Готово: видео восстановлено и сохранено." : "Видео обработано, но не сохранено.");
                                    if (saved != null) loadMediaIntoEditor(saved, true, true);
                                });
                            } catch (Exception e) {
                                String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                                runOnUiThread(() -> setBusy(false, "Ошибка сохранения видео: " + msg));
                            } finally {
                                temp.delete();
                            }
                        }).start();
                    }

                    @Override
                    public void onError(Composition composition, ExportResult exportResult, ExportException exportException) {
                        transformer = null;
                        temp.delete();
                        setBusy(false, "Ошибка видео: " + describeExportError(exportException));
                    }
                })
                .build();

        transformer.start(item, temp.getAbsolutePath());
    }

    private void togglePlayback() {
        if (!selectedVideo || videoDurationMs <= 0) return;
        if (videoPreview.isPlaying()) {
            videoPreview.pause();
            playPauseButton.setText("Продолжить");
        } else {
            if (videoPreview.getCurrentPosition() >= videoDurationMs - 100) videoPreview.seekTo(0);
            videoPreview.start();
            playPauseButton.setText("Пауза");
        }
    }

    private void addMaskKeyframe() {
        if (!selectedVideo || videoDurationMs <= 0) return;
        if (videoPreview.isPlaying()) videoPreview.pause();
        Bitmap mask = maskView.getMaskBitmapCopy();
        if (mask == null) {
            Toast.makeText(this, "Сначала закрасьте watermark кистью на этом кадре.", Toast.LENGTH_LONG).show();
            return;
        }
        long timeUs = videoPreview.getCurrentPosition() * 1000L;
        putKeyframe(new MaskKeyframe(timeUs, mask, true));
        updateKeyframeText();
        statusText.setText("Точная маска сохранена с " + formatTime((int)(timeUs / 1000L)) + ". Она действует до следующей точки.");
    }

    private void addDisabledKeyframe() {
        if (!selectedVideo || videoDurationMs <= 0) return;
        if (videoPreview.isPlaying()) videoPreview.pause();
        long timeUs = videoPreview.getCurrentPosition() * 1000L;
        putKeyframe(new MaskKeyframe(timeUs, null, false));
        maskView.clearMask();
        maskView.setEraseMode(false);
        refreshToolUi();
        updateKeyframeText();
        statusText.setText("С " + formatTime((int)(timeUs / 1000L)) + " восстановление отключено до следующей точки.");
    }

    private void putKeyframe(MaskKeyframe frame) {
        long toleranceUs = 250_000L;
        for (int i = 0; i < keyframes.size(); i++) {
            if (Math.abs(keyframes.get(i).timeUs - frame.timeUs) <= toleranceUs) {
                keyframes.set(i, frame);
                sortKeyframes();
                return;
            }
        }
        keyframes.add(frame);
        sortKeyframes();
    }

    private void sortKeyframes() {
        keyframes.sort(Comparator.comparingLong(k -> k.timeUs));
    }

    private MaskKeyframe keyframeAt(long positionUs) {
        MaskKeyframe current = null;
        for (MaskKeyframe k : keyframes) {
            if (k.timeUs <= positionUs) current = k;
            else break;
        }
        return current;
    }

    private void showMaskForPosition(int positionMs) {
        MaskKeyframe k = keyframeAt(positionMs * 1000L);
        if (k == null) {
            maskView.clearMask();
            maskView.setEraseMode(false);
            refreshToolUi();
            return;
        }
        if (k.active && k.mask != null) {
            maskView.setMaskBitmap(k.mask);
        } else {
            maskView.clearMask();
        }
    }

    private void updateKeyframeText() {
        if (keyframeText == null) return;
        StringBuilder b = new StringBuilder("Точки маски: ").append(keyframes.size());
        if (!keyframes.isEmpty()) {
            b.append("  •  ");
            int count = Math.min(4, keyframes.size());
            for (int i = 0; i < count; i++) {
                if (i > 0) b.append(", ");
                MaskKeyframe k = keyframes.get(i);
                b.append(formatTime((int)(k.timeUs / 1000L)));
                if (!k.active) b.append(" выкл");
            }
            if (keyframes.size() > count) b.append(" …");
        }
        keyframeText.setText(b.toString());
        clearKeyframesButton.setEnabled(!keyframes.isEmpty());
    }

    private void updateTimeText(int positionMs) {
        if (timeText != null) timeText.setText(formatTime(positionMs) + " / " + formatTime(videoDurationMs));
    }

    private String formatTime(int ms) {
        int totalSec = Math.max(0, ms) / 1000;
        int min = totalSec / 60;
        int sec = totalSec % 60;
        int milli = Math.max(0, ms) % 1000;
        return String.format(Locale.US, "%02d:%02d.%03d", min, sec, milli);
    }

    private void setVideoControlsEnabled(boolean enabled) {
        timelineSeek.setEnabled(enabled);
        playPauseButton.setEnabled(enabled);
        addKeyframeButton.setEnabled(enabled);
        disableMaskButton.setEnabled(enabled);
        clearKeyframesButton.setEnabled(enabled && !keyframes.isEmpty());
    }

    private String describeExportError(ExportException e) {
        StringBuilder b = new StringBuilder();
        try {
            b.append(e.getErrorCodeName());
        } catch (RuntimeException ignored) {
            b.append("код ").append(e.errorCode);
        }
        Throwable cause = e.getCause();
        int depth = 0;
        while (cause != null && depth < 3) {
            String msg = cause.getMessage();
            b.append(" • ").append(cause.getClass().getSimpleName());
            if (msg != null && !msg.trim().isEmpty()) {
                msg = msg.replace('\n', ' ').trim();
                if (msg.length() > 140) msg = msg.substring(0, 140);
                b.append(": ").append(msg);
            }
            cause = cause.getCause();
            depth++;
        }
        return b.toString();
    }

    private Uri publishVideo(File source) throws IOException {
        String name = "EdgeCleaner_Inpaint_" + timestamp() + ".mp4";
        ContentResolver resolver = getContentResolver();

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/EdgeCleaner");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri out = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (out == null) throw new IOException("MediaStore insert failed");
            try (InputStream in = new FileInputStream(source); OutputStream os = resolver.openOutputStream(out)) {
                if (os == null) throw new IOException("Не удалось открыть выходной файл");
                copy(in, os);
            }
            values.clear();
            values.put(MediaStore.Video.Media.IS_PENDING, 0);
            resolver.update(out, values, null, null);
            return out;
        }

        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "EdgeCleaner");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Не удалось создать папку");
        File out = new File(dir, name);
        try (InputStream in = new FileInputStream(source); OutputStream os = new FileOutputStream(out)) {
            copy(in, os);
        }
        return Uri.fromFile(out);
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[128 * 1024];
        int n;
        while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
    }

    private void setBusy(boolean busy, String message) {
        progressBar.setVisibility(busy ? View.VISIBLE : View.GONE);
        processButton.setEnabled(!busy && selectedUri != null && (selectedVideo || openCvReady));
        resetMaskButton.setEnabled(!busy && selectedUri != null);
        if (toolModeButton != null) toolModeButton.setEnabled(!busy && selectedUri != null);
        if (autoDetectButton != null) autoDetectButton.setEnabled(!busy && selectedUri != null);
        radiusSeek.setEnabled(!busy);
        brushSeek.setEnabled(!busy);
        if (eraserSeek != null) eraserSeek.setEnabled(!busy);
        smoothSeek.setEnabled(!busy);
        maskView.setEnabled(!busy);
        if (selectedVideo) setVideoControlsEnabled(!busy && videoDurationMs > 0);
        statusText.setText(message);
        if (!busy && message.startsWith("Готово")) Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private String timestamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override
    protected void onDestroy() {
        if (transformer != null) {
            transformer.cancel();
            transformer = null;
        }
        uiHandler.removeCallbacks(timelineTicker);
        videoPreview.stopPlayback();
        super.onDestroy();
    }
}
