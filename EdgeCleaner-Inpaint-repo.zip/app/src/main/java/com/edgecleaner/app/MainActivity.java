package com.edgecleaner.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.OptIn;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;

import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;
import org.opencv.photo.Photo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_IMAGE = 1001;
    private static final int REQ_VIDEO = 1002;

    private Uri selectedUri;
    private boolean selectedVideo;
    private boolean openCvReady;

    private ImageView imagePreview;
    private VideoView videoPreview;
    private MaskSelectionView maskView;
    private SeekBar radiusSeek;
    private TextView radiusText;
    private SeekBar brushSeek;
    private TextView brushText;
    private TextView statusText;
    private ProgressBar progressBar;
    private Button processButton;
    private Button resetMaskButton;

    private LinearLayout videoControls;
    private SeekBar timelineSeek;
    private TextView timeText;
    private TextView keyframeText;
    private Button playPauseButton;
    private Button addKeyframeButton;
    private Button disableMaskButton;
    private Button clearKeyframesButton;
    private int videoDurationMs;
    private boolean timelineTracking;
    private final ArrayList<MaskKeyframe> keyframes = new ArrayList<>();
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable timelineTicker = new Runnable() {
        @Override public void run() {
            if (selectedVideo && videoPreview != null && videoPreview.getVisibility() == View.VISIBLE) {
                if (!timelineTracking && videoDurationMs > 0) {
                    int pos = Math.max(0, videoPreview.getCurrentPosition());
                    timelineSeek.setProgress(Math.min(1000, Math.round(pos * 1000f / videoDurationMs)));
                    updateTimeText(pos);
                    if (videoPreview.isPlaying()) showMaskForPosition(pos);
                }
                playPauseButton.setText(videoPreview.isPlaying() ? "Пауза" : "Продолжить");
            }
            uiHandler.postDelayed(this, 180);
        }
    };

    private Transformer transformer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        openCvReady = OpenCVLoader.initLocal();
        setContentView(buildUi());
        if (!openCvReady) {
            statusText.setText("OpenCV не загрузился. Обработка фото будет недоступна.");
        }
    }

    private View buildUi() {
        int pad = dp(16);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFFF7F7F7);
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        ImageView brandLogo = new ImageView(this);
        brandLogo.setImageResource(R.drawable.edgecleaner_logo);
        brandLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(-1, dp(132));
        logoLp.bottomMargin = dp(4);
        root.addView(brandLogo, logoLp);

        TextView title = new TextView(this);
        title.setText("EdgeCleaner Inpaint Pro");
        title.setTextSize(26f);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView intro = new TextView(this);
        intro.setText("PRO: поставьте видео на паузу и закрасьте watermark пальцем как кистью. Добавьте точку маски. Если watermark меняется — перемотайте и нарисуйте новую маску. Обрабатывается только закрашенная форма, без прямоугольного шва.");
        intro.setTextSize(14f);
        intro.setPadding(0, dp(8), 0, dp(12));
        root.addView(intro, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout pickRow = new LinearLayout(this);
        pickRow.setOrientation(LinearLayout.HORIZONTAL);

        Button pickImage = new Button(this);
        pickImage.setText("Выбрать фото");
        pickImage.setOnClickListener(v -> pickMedia(false));
        pickRow.addView(pickImage, new LinearLayout.LayoutParams(0, -2, 1f));

        Button pickVideo = new Button(this);
        pickVideo.setText("Выбрать видео");
        pickVideo.setOnClickListener(v -> pickMedia(true));
        LinearLayout.LayoutParams videoLp = new LinearLayout.LayoutParams(0, -2, 1f);
        videoLp.setMarginStart(dp(8));
        pickRow.addView(pickVideo, videoLp);
        root.addView(pickRow, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout previewFrame = new FrameLayout(this);
        previewFrame.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(-1, dp(330));
        previewLp.topMargin = dp(10);
        root.addView(previewFrame, previewLp);

        imagePreview = new ImageView(this);
        imagePreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imagePreview.setVisibility(View.GONE);
        previewFrame.addView(imagePreview, new FrameLayout.LayoutParams(-1, -1));

        videoPreview = new VideoView(this);
        videoPreview.setVisibility(View.GONE);
        videoPreview.setOnPreparedListener(mp -> {
            mp.setLooping(false);
            maskView.setContentSize(mp.getVideoWidth(), mp.getVideoHeight());
            maskView.bringToFront();
            maskView.setClickable(true);
            videoDurationMs = Math.max(1, mp.getDuration());
            timelineSeek.setProgress(0);
            videoPreview.seekTo(0);
            videoPreview.pause();
            updateTimeText(0);
            playPauseButton.setText("Продолжить");
            setVideoControlsEnabled(true);
            statusText.setText("Видео готово. Поставьте паузу, закрасьте watermark кистью и нажмите «Добавить маску». ");
        });
        videoPreview.setOnCompletionListener(mp -> {
            playPauseButton.setText("Продолжить");
            updateTimeText(videoDurationMs);
        });
        FrameLayout.LayoutParams videoPreviewLp = new FrameLayout.LayoutParams(-1, -1);
        videoPreviewLp.gravity = Gravity.CENTER;
        previewFrame.addView(videoPreview, videoPreviewLp);

        maskView = new MaskSelectionView(this);
        maskView.setVisibility(View.GONE);
        maskView.setOnBrushStartListener(() -> {
            if (selectedVideo && videoPreview.isPlaying()) {
                videoPreview.pause();
                if (playPauseButton != null) playPauseButton.setText("Продолжить");
            }
        });
        previewFrame.addView(maskView, new FrameLayout.LayoutParams(-1, -1));

        videoControls = new LinearLayout(this);
        videoControls.setOrientation(LinearLayout.VERTICAL);
        videoControls.setVisibility(View.GONE);
        LinearLayout.LayoutParams controlsLp = new LinearLayout.LayoutParams(-1, -2);
        controlsLp.topMargin = dp(8);
        root.addView(videoControls, controlsLp);

        timeText = new TextView(this);
        timeText.setGravity(Gravity.CENTER_HORIZONTAL);
        timeText.setText("00:00.000 / 00:00.000");
        videoControls.addView(timeText, new LinearLayout.LayoutParams(-1, -2));

        timelineSeek = new SeekBar(this);
        timelineSeek.setMax(1000);
        timelineSeek.setEnabled(false);
        timelineSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || videoDurationMs <= 0) return;
                int position = Math.round(videoDurationMs * progress / 1000f);
                videoPreview.seekTo(position);
                updateTimeText(position);
                showMaskForPosition(position);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {
                timelineTracking = true;
                if (videoPreview.isPlaying()) videoPreview.pause();
                playPauseButton.setText("Продолжить");
            }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                timelineTracking = false;
                int position = Math.round(videoDurationMs * seekBar.getProgress() / 1000f);
                videoPreview.seekTo(position);
                showMaskForPosition(position);
            }
        });
        videoControls.addView(timelineSeek, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout transportRow = new LinearLayout(this);
        transportRow.setOrientation(LinearLayout.HORIZONTAL);
        playPauseButton = new Button(this);
        playPauseButton.setText("Продолжить");
        playPauseButton.setEnabled(false);
        playPauseButton.setOnClickListener(v -> togglePlayback());
        transportRow.addView(playPauseButton, new LinearLayout.LayoutParams(0, -2, 1f));

        addKeyframeButton = new Button(this);
        addKeyframeButton.setText("Добавить маску");
        addKeyframeButton.setEnabled(false);
        addKeyframeButton.setOnClickListener(v -> addMaskKeyframe());
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(0, -2, 1f);
        addLp.setMarginStart(dp(8));
        transportRow.addView(addKeyframeButton, addLp);
        videoControls.addView(transportRow, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout maskStateRow = new LinearLayout(this);
        maskStateRow.setOrientation(LinearLayout.HORIZONTAL);
        disableMaskButton = new Button(this);
        disableMaskButton.setText("Без маски отсюда");
        disableMaskButton.setEnabled(false);
        disableMaskButton.setOnClickListener(v -> addDisabledKeyframe());
        maskStateRow.addView(disableMaskButton, new LinearLayout.LayoutParams(0, -2, 1f));

        clearKeyframesButton = new Button(this);
        clearKeyframesButton.setText("Очистить точки");
        clearKeyframesButton.setEnabled(false);
        clearKeyframesButton.setOnClickListener(v -> {
            keyframes.clear();
            updateKeyframeText();
            maskView.clearMask();
            Toast.makeText(this, "Все точки маски удалены", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(0, -2, 1f);
        clearLp.setMarginStart(dp(8));
        maskStateRow.addView(clearKeyframesButton, clearLp);
        videoControls.addView(maskStateRow, new LinearLayout.LayoutParams(-1, -2));

        keyframeText = new TextView(this);
        keyframeText.setText("Точки маски: 0");
        keyframeText.setTextSize(13f);
        keyframeText.setPadding(0, dp(4), 0, 0);
        videoControls.addView(keyframeText, new LinearLayout.LayoutParams(-1, -2));

        TextView maskHint = new TextView(this);
        maskHint.setText("Проведите пальцем по watermark — видео само встанет на паузу, а над пальцем появится лупа. Затем нажмите «Добавить маску». Для новой позиции watermark добавьте новую точку на нужном кадре.");
        maskHint.setTextSize(13f);
        maskHint.setPadding(0, dp(8), 0, dp(2));
        root.addView(maskHint, new LinearLayout.LayoutParams(-1, -2));

        resetMaskButton = new Button(this);
        resetMaskButton.setText("Очистить текущую маску");
        resetMaskButton.setEnabled(false);
        resetMaskButton.setOnClickListener(v -> maskView.clearMask());
        root.addView(resetMaskButton, new LinearLayout.LayoutParams(-1, -2));

        brushText = new TextView(this);
        brushText.setText("Размер кисти: 24");
        brushText.setPadding(0, dp(8), 0, dp(2));
        root.addView(brushText);

        brushSeek = new SeekBar(this);
        brushSeek.setMax(48); // 12..60 dp
        brushSeek.setProgress(12); // 24 dp
        brushSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int size = progress + 12;
                brushText.setText("Размер кисти: " + size);
                maskView.setBrushSizeDp(size);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        root.addView(brushSeek, new LinearLayout.LayoutParams(-1, -2));

        radiusText = new TextView(this);
        radiusText.setText("Мягкость восстановления: 9 px");
        radiusText.setPadding(0, dp(8), 0, dp(2));
        root.addView(radiusText);

        radiusSeek = new SeekBar(this);
        radiusSeek.setMax(21); // 3..24 px
        radiusSeek.setProgress(6); // 9 px
        radiusSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                radiusText.setText("Мягкость восстановления: " + (progress + 3) + " px");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        root.addView(radiusSeek, new LinearLayout.LayoutParams(-1, -2));

        processButton = new Button(this);
        processButton.setText("Восстановить");
        processButton.setEnabled(false);
        processButton.setOnClickListener(v -> processSelected());
        LinearLayout.LayoutParams processLp = new LinearLayout.LayoutParams(-1, -2);
        processLp.topMargin = dp(6);
        root.addView(processButton, processLp);

        progressBar = new ProgressBar(this);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-2, -2);
        progressLp.gravity = Gravity.CENTER_HORIZONTAL;
        progressLp.topMargin = dp(6);
        root.addView(progressBar, progressLp);

        statusText = new TextView(this);
        statusText.setText("Выберите фото или видео.");
        statusText.setGravity(Gravity.CENTER_HORIZONTAL);
        statusText.setPadding(0, dp(6), 0, dp(12));
        root.addView(statusText, new LinearLayout.LayoutParams(-1, -2));

        uiHandler.post(timelineTicker);
        return scroll;
    }

    private void pickMedia(boolean video) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(video ? "video/*" : "image/*");
        startActivityForResult(intent, video ? REQ_VIDEO : REQ_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;

        selectedUri = data.getData();
        selectedVideo = requestCode == REQ_VIDEO;
        try {
            getContentResolver().takePersistableUriPermission(
                    selectedUri,
                    data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
        } catch (Exception ignored) {
        }

        keyframes.clear();
        videoDurationMs = 0;
        updateKeyframeText();
        processButton.setEnabled(selectedVideo || openCvReady);
        resetMaskButton.setEnabled(true);
        maskView.setVisibility(View.VISIBLE);
        maskView.bringToFront();
        maskView.setClickable(true);
        maskView.clearMask();

        if (selectedVideo) {
            imagePreview.setImageDrawable(null);
            imagePreview.setVisibility(View.GONE);
            videoPreview.setVisibility(View.VISIBLE);
            maskView.setMagnifierSource(videoPreview);
            videoControls.setVisibility(View.VISIBLE);
            setVideoControlsEnabled(false);
            videoPreview.setVideoURI(selectedUri);
            statusText.setText("Загрузка видео…");
        } else {
            videoPreview.stopPlayback();
            videoPreview.setVisibility(View.GONE);
            videoControls.setVisibility(View.GONE);
            imagePreview.setVisibility(View.VISIBLE);
            maskView.setMagnifierSource(imagePreview);
            Bitmap preview = loadPreviewBitmap(selectedUri, 1800);
            imagePreview.setImageBitmap(preview);
            if (preview != null) {
                maskView.setContentSize(preview.getWidth(), preview.getHeight());
            }
            statusText.setText(openCvReady
                    ? "Фото выбрано. Закрасьте водяной знак кистью."
                    : "Фото выбрано, но OpenCV не загрузился.");
        }
    }

    private void processSelected() {
        if (selectedUri == null) return;
        int radius = radiusSeek.getProgress() + 3;

        if (selectedVideo) {
            if (keyframes.isEmpty()) {
                ArrayList<MaskCircle> circles = maskView.getNormalizedCircles(8);
                if (circles.isEmpty()) {
                    Toast.makeText(this, "Сначала закрасьте watermark кистью или добавьте точку маски.", Toast.LENGTH_LONG).show();
                    return;
                }
                keyframes.add(new MaskKeyframe(videoPreview.getCurrentPosition() * 1000L, circles, true));
                sortKeyframes();
                updateKeyframeText();
            }
            setBusy(true, "PRO-восстановление видео по " + keyframes.size() + " точкам маски…");
            processVideo(selectedUri, new ArrayList<>(keyframes), radius);
            return;
        }

        ArrayList<MaskCircle> circles = maskView.getNormalizedCircles();
        if (circles.isEmpty()) {
            Toast.makeText(this, "Сначала закрасьте водяной знак кистью.", Toast.LENGTH_LONG).show();
            return;
        }
        setBusy(true, "Восстановление фото…");
        new Thread(() -> processImage(selectedUri, circles, radius)).start();
    }

    private void processImage(Uri uri, List<MaskCircle> normalizedMask, int radius) {
        Bitmap source = null;
        Bitmap result = null;
        Mat rgba = null;
        Mat rgb = null;
        Mat mask = null;
        Mat restored = null;
        Mat outRgba = null;
        try {
            if (!openCvReady) throw new IOException("OpenCV не инициализирован");
            source = decodeBitmap(uri);
            if (source == null) throw new IOException("Не удалось декодировать изображение");

            int w = source.getWidth();
            int h = source.getHeight();

            rgba = new Mat();
            Utils.bitmapToMat(source, rgba);
            rgb = new Mat();
            Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB);

            mask = Mat.zeros(h, w, CvType.CV_8UC1);
            int pad = Math.max(2, radius / 2);
            for (MaskCircle c : normalizedMask) {
                int cx = clamp(Math.round(c.x * w), 0, w - 1);
                int cy = clamp(Math.round(c.y * h), 0, h - 1);
                int rx = Math.max(2, Math.round(c.rx * w));
                int ry = Math.max(2, Math.round(c.ry * h));
                int rr = Math.max(rx, ry) + pad;
                Imgproc.circle(mask, new Point(cx, cy), rr, new Scalar(255), -1);
            }

            restored = new Mat();
            Photo.inpaint(rgb, mask, restored, radius, Photo.INPAINT_TELEA);

            outRgba = new Mat();
            Imgproc.cvtColor(restored, outRgba, Imgproc.COLOR_RGB2RGBA);
            result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Utils.matToBitmap(outRgba, result);

            Uri saved = saveBitmap(result);
            Uri finalSaved = saved;
            runOnUiThread(() -> {
                setBusy(false, finalSaved != null ? "Готово: фото восстановлено и сохранено." : "Восстановлено, но не удалось сохранить файл.");
                if (finalSaved != null) {
                    imagePreview.setImageURI(finalSaved);
                    maskView.setVisibility(View.GONE);
                }
            });
        } catch (Exception e) {
            String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            runOnUiThread(() -> setBusy(false, "Ошибка фото: " + msg));
        } finally {
            if (outRgba != null) outRgba.release();
            if (restored != null) restored.release();
            if (mask != null) mask.release();
            if (rgb != null) rgb.release();
            if (rgba != null) rgba.release();
            if (result != null && result != source && !result.isRecycled()) result.recycle();
            if (source != null && !source.isRecycled()) source.recycle();
        }
    }

    private Bitmap decodeBitmap(Uri uri) throws IOException {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.Source src = ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(src, (decoder, info, s) -> decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE));
        }
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            return BitmapFactory.decodeStream(in);
        }
    }

    private Bitmap loadPreviewBitmap(Uri uri, int maxDim) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            int sample = 1;
            while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > maxDim) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = Math.max(1, sample);
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                return BitmapFactory.decodeStream(in, null, opts);
            }
        } catch (Exception e) {
            return null;
        }
    }

    private Uri saveBitmap(Bitmap bitmap) throws IOException {
        String name = "EdgeCleaner_Inpaint_" + timestamp() + ".jpg";
        ContentResolver resolver = getContentResolver();

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/EdgeCleaner");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri out = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (out == null) throw new IOException("MediaStore insert failed");
            try (OutputStream os = resolver.openOutputStream(out)) {
                if (os == null || !bitmap.compress(Bitmap.CompressFormat.JPEG, 95, os)) {
                    throw new IOException("Не удалось записать JPEG");
                }
            }
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(out, values, null, null);
            return out;
        }

        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "EdgeCleaner");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Не удалось создать папку");
        File out = new File(dir, name);
        try (OutputStream os = new FileOutputStream(out)) {
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 95, os)) throw new IOException("Не удалось записать JPEG");
        }
        return Uri.fromFile(out);
    }

    @OptIn(markerClass = UnstableApi.class)
    private void processVideo(Uri uri, List<MaskKeyframe> masks, int radius) {
        Effect restore = new VideoInpaintEffect(masks, radius);
        EditedMediaItem item = new EditedMediaItem.Builder(MediaItem.fromUri(uri))
                .setEffects(new Effects(Collections.emptyList(), Collections.singletonList(restore)))
                .build();

        File temp = new File(getCacheDir(), "edgecleaner_inpaint_" + timestamp() + ".mp4");
        if (temp.exists()) temp.delete();

        transformer = new Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(new Transformer.Listener() {
                    @Override
                    public void onCompleted(Composition composition, ExportResult exportResult) {
                        transformer = null;
                        new Thread(() -> {
                            try {
                                Uri saved = publishVideo(temp);
                                runOnUiThread(() -> {
                                    setBusy(false, saved != null ? "Готово: видео восстановлено и сохранено." : "Видео обработано, но не сохранено.");
                                    if (saved != null) maskView.setVisibility(View.GONE);
                                });
                            } catch (Exception e) {
                                String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                                runOnUiThread(() -> setBusy(false, "Ошибка сохранения видео: " + msg));
                            } finally {
                                temp.delete();
                            }
                        }).start();
                    }

                    @Override
                    public void onError(Composition composition, ExportResult exportResult, ExportException exportException) {
                        transformer = null;
                        temp.delete();
                        setBusy(false, "Ошибка видео: " + describeExportError(exportException));
                    }
                })
                .build();

        transformer.start(item, temp.getAbsolutePath());
    }

    private void togglePlayback() {
        if (!selectedVideo || videoDurationMs <= 0) return;
        if (videoPreview.isPlaying()) {
            videoPreview.pause();
            playPauseButton.setText("Продолжить");
        } else {
            if (videoPreview.getCurrentPosition() >= videoDurationMs - 100) videoPreview.seekTo(0);
            videoPreview.start();
            playPauseButton.setText("Пауза");
        }
    }

    private void addMaskKeyframe() {
        if (!selectedVideo || videoDurationMs <= 0) return;
        if (videoPreview.isPlaying()) videoPreview.pause();
        ArrayList<MaskCircle> circles = maskView.getNormalizedCircles(8);
        if (circles.isEmpty()) {
            Toast.makeText(this, "Сначала закрасьте watermark кистью на этом кадре.", Toast.LENGTH_LONG).show();
            return;
        }
        long timeUs = videoPreview.getCurrentPosition() * 1000L;
        putKeyframe(new MaskKeyframe(timeUs, circles, true));
        updateKeyframeText();
        statusText.setText("Маска сохранена с " + formatTime((int)(timeUs / 1000L)) + ". Она действует до следующей точки.");
    }

    private void addDisabledKeyframe() {
        if (!selectedVideo || videoDurationMs <= 0) return;
        if (videoPreview.isPlaying()) videoPreview.pause();
        long timeUs = videoPreview.getCurrentPosition() * 1000L;
        putKeyframe(new MaskKeyframe(timeUs, Collections.emptyList(), false));
        maskView.clearMask();
        updateKeyframeText();
        statusText.setText("С " + formatTime((int)(timeUs / 1000L)) + " восстановление отключено до следующей точки.");
    }

    private void putKeyframe(MaskKeyframe frame) {
        long toleranceUs = 250_000L;
        for (int i = 0; i < keyframes.size(); i++) {
            if (Math.abs(keyframes.get(i).timeUs - frame.timeUs) <= toleranceUs) {
                keyframes.set(i, frame);
                sortKeyframes();
                return;
            }
        }
        keyframes.add(frame);
        sortKeyframes();
    }

    private void sortKeyframes() {
        keyframes.sort(Comparator.comparingLong(k -> k.timeUs));
    }

    private MaskKeyframe keyframeAt(long positionUs) {
        MaskKeyframe current = null;
        for (MaskKeyframe k : keyframes) {
            if (k.timeUs <= positionUs) current = k;
            else break;
        }
        return current;
    }

    private void showMaskForPosition(int positionMs) {
        MaskKeyframe k = keyframeAt(positionMs * 1000L);
        if (k == null) {
            maskView.clearMask();
            return;
        }
        if (k.active && !k.circles.isEmpty()) maskView.setNormalizedCircles(k.circles);
        else maskView.clearMask();
    }

    private void updateKeyframeText() {
        if (keyframeText == null) return;
        StringBuilder b = new StringBuilder("Точки маски: ").append(keyframes.size());
        if (!keyframes.isEmpty()) {
            b.append("  •  ");
            int count = Math.min(4, keyframes.size());
            for (int i = 0; i < count; i++) {
                if (i > 0) b.append(", ");
                MaskKeyframe k = keyframes.get(i);
                b.append(formatTime((int)(k.timeUs / 1000L)));
                if (!k.active) b.append(" выкл");
            }
            if (keyframes.size() > count) b.append(" …");
        }
        keyframeText.setText(b.toString());
        clearKeyframesButton.setEnabled(!keyframes.isEmpty());
    }

    private void updateTimeText(int positionMs) {
        if (timeText != null) timeText.setText(formatTime(positionMs) + " / " + formatTime(videoDurationMs));
    }

    private String formatTime(int ms) {
        int totalSec = Math.max(0, ms) / 1000;
        int min = totalSec / 60;
        int sec = totalSec % 60;
        int milli = Math.max(0, ms) % 1000;
        return String.format(Locale.US, "%02d:%02d.%03d", min, sec, milli);
    }

    private void setVideoControlsEnabled(boolean enabled) {
        timelineSeek.setEnabled(enabled);
        playPauseButton.setEnabled(enabled);
        addKeyframeButton.setEnabled(enabled);
        disableMaskButton.setEnabled(enabled);
        clearKeyframesButton.setEnabled(enabled && !keyframes.isEmpty());
    }

    private String describeExportError(ExportException e) {
        StringBuilder b = new StringBuilder();
        try {
            b.append(e.getErrorCodeName());
        } catch (RuntimeException ignored) {
            b.append("код ").append(e.errorCode);
        }
        Throwable cause = e.getCause();
        int depth = 0;
        while (cause != null && depth < 3) {
            String msg = cause.getMessage();
            b.append(" • ").append(cause.getClass().getSimpleName());
            if (msg != null && !msg.trim().isEmpty()) {
                msg = msg.replace('\n', ' ').trim();
                if (msg.length() > 140) msg = msg.substring(0, 140);
                b.append(": ").append(msg);
            }
            cause = cause.getCause();
            depth++;
        }
        return b.toString();
    }

    private Uri publishVideo(File source) throws IOException {
        String name = "EdgeCleaner_Inpaint_" + timestamp() + ".mp4";
        ContentResolver resolver = getContentResolver();

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/EdgeCleaner");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri out = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (out == null) throw new IOException("MediaStore insert failed");
            try (InputStream in = new FileInputStream(source); OutputStream os = resolver.openOutputStream(out)) {
                if (os == null) throw new IOException("Не удалось открыть выходной файл");
                copy(in, os);
            }
            values.clear();
            values.put(MediaStore.Video.Media.IS_PENDING, 0);
            resolver.update(out, values, null, null);
            return out;
        }

        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "EdgeCleaner");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Не удалось создать папку");
        File out = new File(dir, name);
        try (InputStream in = new FileInputStream(source); OutputStream os = new FileOutputStream(out)) {
            copy(in, os);
        }
        return Uri.fromFile(out);
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[128 * 1024];
        int n;
        while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
    }

    private void setBusy(boolean busy, String message) {
        progressBar.setVisibility(busy ? View.VISIBLE : View.GONE);
        processButton.setEnabled(!busy && selectedUri != null && (selectedVideo || openCvReady));
        resetMaskButton.setEnabled(!busy && selectedUri != null);
        radiusSeek.setEnabled(!busy);
        brushSeek.setEnabled(!busy);
        maskView.setEnabled(!busy);
        if (selectedVideo) setVideoControlsEnabled(!busy && videoDurationMs > 0);
        statusText.setText(message);
        if (!busy && message.startsWith("Готово")) Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private String timestamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override
    protected void onDestroy() {
        if (transformer != null) {
            transformer.cancel();
            transformer = null;
        }
        uiHandler.removeCallbacks(timelineTicker);
        videoPreview.stopPlayback();
        super.onDestroy();
    }
}
