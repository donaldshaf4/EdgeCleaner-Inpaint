package com.edgecleaner.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.OptIn;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;

import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;
import org.opencv.photo.Photo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_IMAGE = 1001;
    private static final int REQ_VIDEO = 1002;

    private Uri selectedUri;
    private boolean selectedVideo;
    private boolean openCvReady;

    private ImageView imagePreview;
    private VideoView videoPreview;
    private MaskSelectionView maskView;
    private SeekBar radiusSeek;
    private TextView radiusText;
    private TextView statusText;
    private ProgressBar progressBar;
    private Button processButton;
    private Button resetMaskButton;

    private Transformer transformer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        openCvReady = OpenCVLoader.initLocal();
        setContentView(buildUi());
        if (!openCvReady) {
            statusText.setText("OpenCV не загрузился. Обработка фото будет недоступна.");
        }
    }

    private View buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFFF7F7F7);

        TextView title = new TextView(this);
        title.setText("EdgeCleaner Inpaint");
        title.setTextSize(28f);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView intro = new TextView(this);
        intro.setText("Выберите файл и проведите пальцем по водяному знаку. Фото восстанавливаются OpenCV inpainting, видео — покадровым заполнением из окружающих пикселей без обрезки кадра. Используйте только для материалов, которые вам разрешено редактировать.");
        intro.setTextSize(14.5f);
        intro.setPadding(0, dp(10), 0, dp(14));
        root.addView(intro, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout pickRow = new LinearLayout(this);
        pickRow.setOrientation(LinearLayout.HORIZONTAL);

        Button pickImage = new Button(this);
        pickImage.setText("Выбрать фото");
        pickImage.setOnClickListener(v -> pickMedia(false));
        pickRow.addView(pickImage, new LinearLayout.LayoutParams(0, -2, 1f));

        Button pickVideo = new Button(this);
        pickVideo.setText("Выбрать видео");
        pickVideo.setOnClickListener(v -> pickMedia(true));
        LinearLayout.LayoutParams videoLp = new LinearLayout.LayoutParams(0, -2, 1f);
        videoLp.setMarginStart(dp(8));
        pickRow.addView(pickVideo, videoLp);
        root.addView(pickRow, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout previewFrame = new FrameLayout(this);
        previewFrame.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(-1, dp(320));
        previewLp.topMargin = dp(12);
        root.addView(previewFrame, previewLp);

        imagePreview = new ImageView(this);
        imagePreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imagePreview.setVisibility(View.GONE);
        previewFrame.addView(imagePreview, new FrameLayout.LayoutParams(-1, -1));

        videoPreview = new VideoView(this);
        videoPreview.setVisibility(View.GONE);
        videoPreview.setOnPreparedListener(mp -> {
            mp.setLooping(true);
            maskView.setContentSize(mp.getVideoWidth(), mp.getVideoHeight());
            // VideoView preserves the video's aspect ratio and may measure smaller than
            // the preview frame. Center it so its real on-screen bounds match the
            // centered contentRect used by MaskSelectionView.
            videoPreview.requestLayout();
            videoPreview.start();
        });
        FrameLayout.LayoutParams videoPreviewLp = new FrameLayout.LayoutParams(-1, -1);
        videoPreviewLp.gravity = Gravity.CENTER;
        previewFrame.addView(videoPreview, videoPreviewLp);

        maskView = new MaskSelectionView(this);
        maskView.setVisibility(View.GONE);
        previewFrame.addView(maskView, new FrameLayout.LayoutParams(-1, -1));

        TextView maskHint = new TextView(this);
        maskHint.setText("Маска: протяните пальцем прямоугольник вокруг водяного знака. Лучше захватить 2–5 px чистого фона вокруг него.");
        maskHint.setTextSize(13f);
        maskHint.setPadding(0, dp(8), 0, dp(2));
        root.addView(maskHint, new LinearLayout.LayoutParams(-1, -2));

        resetMaskButton = new Button(this);
        resetMaskButton.setText("Сбросить маску");
        resetMaskButton.setEnabled(false);
        resetMaskButton.setOnClickListener(v -> maskView.setDefaultMask());
        root.addView(resetMaskButton, new LinearLayout.LayoutParams(-1, -2));

        radiusText = new TextView(this);
        radiusText.setText("Радиус восстановления: 7 px");
        radiusText.setPadding(0, dp(10), 0, dp(2));
        root.addView(radiusText);

        radiusSeek = new SeekBar(this);
        radiusSeek.setMax(17); // 3..20 px
        radiusSeek.setProgress(4); // 7 px
        radiusSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                radiusText.setText("Радиус восстановления: " + (progress + 3) + " px");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        root.addView(radiusSeek, new LinearLayout.LayoutParams(-1, -2));

        processButton = new Button(this);
        processButton.setText("Восстановить");
        processButton.setEnabled(false);
        processButton.setOnClickListener(v -> processSelected());
        LinearLayout.LayoutParams processLp = new LinearLayout.LayoutParams(-1, -2);
        processLp.topMargin = dp(8);
        root.addView(processButton, processLp);

        progressBar = new ProgressBar(this);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-2, -2);
        progressLp.gravity = Gravity.CENTER_HORIZONTAL;
        progressLp.topMargin = dp(8);
        root.addView(progressBar, progressLp);

        statusText = new TextView(this);
        statusText.setText("Выберите фото или видео.");
        statusText.setGravity(Gravity.CENTER_HORIZONTAL);
        statusText.setPadding(0, dp(8), 0, 0);
        root.addView(statusText, new LinearLayout.LayoutParams(-1, -2));

        return root;
    }

    private void pickMedia(boolean video) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(video ? "video/*" : "image/*");
        startActivityForResult(intent, video ? REQ_VIDEO : REQ_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;

        selectedUri = data.getData();
        selectedVideo = requestCode == REQ_VIDEO;
        try {
            getContentResolver().takePersistableUriPermission(
                    selectedUri,
                    data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
        } catch (Exception ignored) {
        }

        processButton.setEnabled(selectedVideo || openCvReady);
        resetMaskButton.setEnabled(true);
        maskView.setVisibility(View.VISIBLE);

        if (selectedVideo) {
            imagePreview.setImageDrawable(null);
            imagePreview.setVisibility(View.GONE);
            videoPreview.setVisibility(View.VISIBLE);
            videoPreview.setVideoURI(selectedUri);
            videoPreview.start();
            statusText.setText("Видео выбрано. Обведите водяной знак.");
        } else {
            videoPreview.stopPlayback();
            videoPreview.setVisibility(View.GONE);
            imagePreview.setVisibility(View.VISIBLE);
            Bitmap preview = loadPreviewBitmap(selectedUri, 1800);
            imagePreview.setImageBitmap(preview);
            if (preview != null) {
                maskView.setContentSize(preview.getWidth(), preview.getHeight());
            }
            statusText.setText(openCvReady
                    ? "Фото выбрано. Обведите водяной знак."
                    : "Фото выбрано, но OpenCV не загрузился.");
        }
    }

    private void processSelected() {
        if (selectedUri == null) return;
        RectF mask = maskView.getNormalizedRect();
        if (mask == null) {
            Toast.makeText(this, "Сначала выделите водяной знак.", Toast.LENGTH_LONG).show();
            return;
        }
        int radius = radiusSeek.getProgress() + 3;
        setBusy(true, selectedVideo ? "Восстановление видео…" : "Восстановление фото…");
        if (selectedVideo) {
            processVideo(selectedUri, new RectF(mask), radius);
        } else {
            new Thread(() -> processImage(selectedUri, new RectF(mask), radius)).start();
        }
    }

    private void processImage(Uri uri, RectF normalizedMask, int radius) {
        Bitmap source = null;
        Bitmap result = null;
        Mat rgba = null;
        Mat rgb = null;
        Mat mask = null;
        Mat restored = null;
        Mat outRgba = null;
        try {
            if (!openCvReady) throw new IOException("OpenCV не инициализирован");
            source = decodeBitmap(uri);
            if (source == null) throw new IOException("Не удалось декодировать изображение");

            int w = source.getWidth();
            int h = source.getHeight();
            int pad = Math.max(2, radius / 2);
            int left = clamp(Math.round(normalizedMask.left * w) - pad, 0, w - 1);
            int top = clamp(Math.round(normalizedMask.top * h) - pad, 0, h - 1);
            int right = clamp(Math.round(normalizedMask.right * w) + pad, left + 1, w);
            int bottom = clamp(Math.round(normalizedMask.bottom * h) + pad, top + 1, h);

            rgba = new Mat();
            Utils.bitmapToMat(source, rgba);
            rgb = new Mat();
            Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB);

            mask = Mat.zeros(h, w, CvType.CV_8UC1);
            Imgproc.rectangle(mask, new Point(left, top), new Point(right - 1, bottom - 1), new Scalar(255), -1);

            restored = new Mat();
            Photo.inpaint(rgb, mask, restored, radius, Photo.INPAINT_TELEA);

            outRgba = new Mat();
            Imgproc.cvtColor(restored, outRgba, Imgproc.COLOR_RGB2RGBA);
            result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Utils.matToBitmap(outRgba, result);

            Uri saved = saveBitmap(result);
            Uri finalSaved = saved;
            runOnUiThread(() -> {
                setBusy(false, finalSaved != null ? "Готово: фото восстановлено и сохранено." : "Восстановлено, но не удалось сохранить файл.");
                if (finalSaved != null) {
                    imagePreview.setImageURI(finalSaved);
                    maskView.setVisibility(View.GONE);
                }
            });
        } catch (Exception e) {
            String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            runOnUiThread(() -> setBusy(false, "Ошибка фото: " + msg));
        } finally {
            if (outRgba != null) outRgba.release();
            if (restored != null) restored.release();
            if (mask != null) mask.release();
            if (rgb != null) rgb.release();
            if (rgba != null) rgba.release();
            if (result != null && result != source && !result.isRecycled()) result.recycle();
            if (source != null && !source.isRecycled()) source.recycle();
        }
    }

    private Bitmap decodeBitmap(Uri uri) throws IOException {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.Source src = ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(src, (decoder, info, s) -> decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE));
        }
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            return BitmapFactory.decodeStream(in);
        }
    }

    private Bitmap loadPreviewBitmap(Uri uri, int maxDim) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            int sample = 1;
            while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > maxDim) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = Math.max(1, sample);
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                return BitmapFactory.decodeStream(in, null, opts);
            }
        } catch (Exception e) {
            return null;
        }
    }

    private Uri saveBitmap(Bitmap bitmap) throws IOException {
        String name = "EdgeCleaner_Inpaint_" + timestamp() + ".jpg";
        ContentResolver resolver = getContentResolver();

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/EdgeCleaner");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri out = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (out == null) throw new IOException("MediaStore insert failed");
            try (OutputStream os = resolver.openOutputStream(out)) {
                if (os == null || !bitmap.compress(Bitmap.CompressFormat.JPEG, 95, os)) {
                    throw new IOException("Не удалось записать JPEG");
                }
            }
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(out, values, null, null);
            return out;
        }

        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "EdgeCleaner");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Не удалось создать папку");
        File out = new File(dir, name);
        try (OutputStream os = new FileOutputStream(out)) {
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 95, os)) throw new IOException("Не удалось записать JPEG");
        }
        return Uri.fromFile(out);
    }

    @OptIn(markerClass = UnstableApi.class)
    private void processVideo(Uri uri, RectF mask, int radius) {
        Effect restore = new VideoInpaintEffect(mask.left, mask.top, mask.right, mask.bottom, radius);
        EditedMediaItem item = new EditedMediaItem.Builder(MediaItem.fromUri(uri))
                .setEffects(new Effects(Collections.emptyList(), Collections.singletonList(restore)))
                .build();

        File temp = new File(getCacheDir(), "edgecleaner_inpaint_" + timestamp() + ".mp4");
        if (temp.exists()) temp.delete();

        transformer = new Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(new Transformer.Listener() {
                    @Override
                    public void onCompleted(Composition composition, ExportResult exportResult) {
                        transformer = null;
                        new Thread(() -> {
                            try {
                                Uri saved = publishVideo(temp);
                                runOnUiThread(() -> {
                                    setBusy(false, saved != null ? "Готово: видео восстановлено и сохранено." : "Видео обработано, но не сохранено.");
                                    if (saved != null) maskView.setVisibility(View.GONE);
                                });
                            } catch (Exception e) {
                                String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                                runOnUiThread(() -> setBusy(false, "Ошибка сохранения видео: " + msg));
                            } finally {
                                temp.delete();
                            }
                        }).start();
                    }

                    @Override
                    public void onError(Composition composition, ExportResult exportResult, ExportException exportException) {
                        transformer = null;
                        temp.delete();
                        setBusy(false, "Ошибка видео: " + exportException.getMessage());
                    }
                })
                .build();

        transformer.start(item, temp.getAbsolutePath());
    }

    private Uri publishVideo(File source) throws IOException {
        String name = "EdgeCleaner_Inpaint_" + timestamp() + ".mp4";
        ContentResolver resolver = getContentResolver();

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/EdgeCleaner");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri out = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (out == null) throw new IOException("MediaStore insert failed");
            try (InputStream in = new FileInputStream(source); OutputStream os = resolver.openOutputStream(out)) {
                if (os == null) throw new IOException("Не удалось открыть выходной файл");
                copy(in, os);
            }
            values.clear();
            values.put(MediaStore.Video.Media.IS_PENDING, 0);
            resolver.update(out, values, null, null);
            return out;
        }

        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "EdgeCleaner");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Не удалось создать папку");
        File out = new File(dir, name);
        try (InputStream in = new FileInputStream(source); OutputStream os = new FileOutputStream(out)) {
            copy(in, os);
        }
        return Uri.fromFile(out);
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[128 * 1024];
        int n;
        while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
    }

    private void setBusy(boolean busy, String message) {
        progressBar.setVisibility(busy ? View.VISIBLE : View.GONE);
        processButton.setEnabled(!busy && selectedUri != null && (selectedVideo || openCvReady));
        resetMaskButton.setEnabled(!busy && selectedUri != null);
        radiusSeek.setEnabled(!busy);
        maskView.setEnabled(!busy);
        statusText.setText(message);
        if (!busy && message.startsWith("Готово")) Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private String timestamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override
    protected void onDestroy() {
        if (transformer != null) {
            transformer.cancel();
            transformer = null;
        }
        videoPreview.stopPlayback();
        super.onDestroy();
    }
}
