package com.edgecleaner.app;

import android.graphics.Bitmap;
import android.graphics.RectF;

/** Time-based raster watermark mask state for video restoration. */
public final class MaskKeyframe {
    public final long timeUs;
    public final Bitmap mask;
    public final boolean active;
    public final RectF bounds;

    public MaskKeyframe(long timeUs, Bitmap mask, boolean active) {
        this.timeUs = Math.max(0L, timeUs);
        this.mask = mask;
        this.bounds = mask == null ? null : findBounds(mask);
        this.active = active && this.mask != null && this.bounds != null;
    }

    private static RectF findBounds(Bitmap bitmap) {
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        if (w <= 0 || h <= 0) return null;

        int left = w, top = h, right = -1, bottom = -1;
        int[] row = new int[w];
        for (int y = 0; y < h; y++) {
            bitmap.getPixels(row, 0, w, 0, y, w, 1);
            for (int x = 0; x < w; x++) {
                if (((row[x] >>> 24) & 0xFF) > 12) {
                    if (x < left) left = x;
                    if (x > right) right = x;
                    if (y < top) top = y;
                    if (y > bottom) bottom = y;
                }
            }
        }
        if (right < left || bottom < top) return null;
        return new RectF(
                left / (float) w,
                top / (float) h,
                (right + 1) / (float) w,
                (bottom + 1) / (float) h);
    }
}
