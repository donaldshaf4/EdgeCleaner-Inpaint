package com.edgecleaner.app;

import android.graphics.RectF;

/** Time-based watermark mask state for video restoration. */
public final class MaskKeyframe {
    public final long timeUs;
    public final RectF rect;
    public final boolean active;

    public MaskKeyframe(long timeUs, RectF rect, boolean active) {
        this.timeUs = Math.max(0L, timeUs);
        this.rect = rect == null ? null : new RectF(rect);
        this.active = active && rect != null;
    }
}
