package com.edgecleaner.app;

import android.graphics.RectF;
import java.util.ArrayList;
import java.util.List;

/** Time-based freehand watermark mask state for video restoration. */
public final class MaskKeyframe {
    public final long timeUs;
    public final ArrayList<MaskCircle> circles;
    public final boolean active;

    public MaskKeyframe(long timeUs, List<MaskCircle> circles, boolean active) {
        this.timeUs = Math.max(0L, timeUs);
        this.circles = new ArrayList<>();
        if (circles != null) {
            for (MaskCircle c : circles) this.circles.add(new MaskCircle(c));
        }
        this.active = active && !this.circles.isEmpty();
    }

    public RectF bounds() {
        if (circles.isEmpty()) return null;
        float left = 1f, top = 1f, right = 0f, bottom = 0f;
        for (MaskCircle c : circles) {
            left = Math.min(left, c.x - c.rx);
            top = Math.min(top, c.y - c.ry);
            right = Math.max(right, c.x + c.rx);
            bottom = Math.max(bottom, c.y + c.ry);
        }
        return new RectF(clamp01(left), clamp01(top), clamp01(right), clamp01(bottom));
    }

    private static float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }
}
