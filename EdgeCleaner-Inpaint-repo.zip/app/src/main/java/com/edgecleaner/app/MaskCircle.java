package com.edgecleaner.app;

/** One normalized brush dab over the displayed media. */
public final class MaskCircle {
    public final float x;
    public final float y;
    public final float rx;
    public final float ry;

    public MaskCircle(float x, float y, float rx, float ry) {
        this.x = clamp01(x);
        this.y = clamp01(y);
        this.rx = Math.max(0.001f, rx);
        this.ry = Math.max(0.001f, ry);
    }

    public MaskCircle(MaskCircle other) {
        this(other.x, other.y, other.rx, other.ry);
    }

    private static float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }
}
