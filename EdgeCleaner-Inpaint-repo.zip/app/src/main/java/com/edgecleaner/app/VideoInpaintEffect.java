package com.edgecleaner.app;

import android.content.Context;
import android.graphics.RectF;
import android.opengl.GLES20;

import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlProgram;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.Size;
import androidx.media3.effect.BaseGlShaderProgram;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.GlShaderProgram;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Pro video restoration effect using a freehand brush mask.
 *
 * The mask is represented by up to eight soft ellipses rather than one rectangle, so only the
 * painted watermark area is blended. Sampling is directional: sides with more clean room inside
 * the frame receive more weight, which is especially useful for corner watermarks and avoids the
 * reflected/duplicated look caused by mirror filling.
 */
public final class VideoInpaintEffect implements GlEffect {
    private static final int MAX_CIRCLES = 8;

    private final ArrayList<MaskKeyframe> keyframes;
    private final float featherPixels;

    public VideoInpaintEffect(List<MaskKeyframe> keyframes, float featherPixels) {
        this.keyframes = new ArrayList<>();
        if (keyframes != null) {
            for (MaskKeyframe k : keyframes) {
                this.keyframes.add(new MaskKeyframe(k.timeUs, k.circles, k.active));
            }
        }
        this.keyframes.sort(Comparator.comparingLong(k -> k.timeUs));
        this.featherPixels = featherPixels;
    }

    @Override
    public GlShaderProgram toGlShaderProgram(Context context, boolean useHdr)
            throws VideoFrameProcessingException {
        if (useHdr) throw new VideoFrameProcessingException("HDR video restoration is not supported yet.");
        return new Program(context, keyframes, featherPixels);
    }

    private static final class Program extends BaseGlShaderProgram {
        private final GlProgram glProgram;
        private final ArrayList<MaskKeyframe> keyframes;
        private final float featherPixels;
        private int inputWidth;
        private int inputHeight;

        Program(Context context, List<MaskKeyframe> keyframes, float featherPixels)
                throws VideoFrameProcessingException {
            super(false, 1);
            this.keyframes = new ArrayList<>(keyframes);
            this.featherPixels = featherPixels;
            try {
                glProgram = new GlProgram(context, R.raw.vertex_shader_inpaint_es2, R.raw.fragment_shader_inpaint_es2);
                glProgram.setBufferAttribute(
                        "aFramePosition",
                        GlUtil.getNormalizedCoordinateBounds(),
                        GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE);
                float[] identity = GlUtil.create4x4IdentityMatrix();
                glProgram.setFloatsUniform("uTransformationMatrix", identity);
                glProgram.setFloatsUniform("uTexTransformationMatrix", identity);
            } catch (IOException | GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }

        @Override
        public Size configure(int inputWidth, int inputHeight) {
            this.inputWidth = inputWidth;
            this.inputHeight = inputHeight;
            glProgram.setFloatsUniform("uTexel", new float[]{1f / inputWidth, 1f / inputHeight});
            return new Size(inputWidth, inputHeight);
        }

        @Override
        public void drawFrame(int inputTexId, long presentationTimeUs)
                throws VideoFrameProcessingException {
            try {
                MaskKeyframe state = stateAt(presentationTimeUs);
                glProgram.use();
                glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0);

                if (state == null || !state.active || state.circles.isEmpty()) {
                    glProgram.setFloatUniform("uEnabled", 0f);
                    setEmptyUniforms();
                } else {
                    ArrayList<MaskCircle> circles = simplify(state.circles, MAX_CIRCLES);
                    RectF bounds = bounds(circles);
                    if (bounds == null) {
                        glProgram.setFloatUniform("uEnabled", 0f);
                        setEmptyUniforms();
                    } else {
                        float pxX = 1f / Math.max(1, inputWidth);
                        float pxY = 1f / Math.max(1, inputHeight);
                        float featherX = Math.max(pxX * 2.5f, featherPixels / inputWidth);
                        float featherY = Math.max(pxY * 2.5f, featherPixels / inputHeight);
                        float expandX = Math.max(featherX * 2.2f, pxX * 5f);
                        float expandY = Math.max(featherY * 2.2f, pxY * 5f);

                        float coreBottom = 1f - bounds.bottom;
                        float coreTop = 1f - bounds.top;
                        float outerLeft = clamp01(bounds.left - expandX);
                        float outerRight = clamp01(bounds.right + expandX);
                        float outerBottom = 1f - clamp01(bounds.bottom + expandY);
                        float outerTop = 1f - clamp01(bounds.top - expandY);

                        float leftSpace = Math.max(0.015f, outerLeft);
                        float rightSpace = Math.max(0.015f, 1f - outerRight);
                        float bottomSpace = Math.max(0.015f, outerBottom);
                        float topSpace = Math.max(0.015f, 1f - outerTop);
                        // Squaring strongly suppresses frame-edge sides for corner watermarks.
                        float wL = leftSpace * leftSpace;
                        float wR = rightSpace * rightSpace;
                        float wB = bottomSpace * bottomSpace;
                        float wT = topSpace * topSpace;
                        float sum = Math.max(0.0001f, wL + wR + wB + wT);

                        glProgram.setFloatUniform("uEnabled", 1f);
                        glProgram.setFloatsUniform("uCoreRect", new float[]{bounds.left, coreBottom, bounds.right, coreTop});
                        glProgram.setFloatsUniform("uOuterRect", new float[]{outerLeft, outerBottom, outerRight, outerTop});
                        glProgram.setFloatsUniform("uFeather", new float[]{featherX, featherY});
                        glProgram.setFloatsUniform("uSideWeights", new float[]{wL / sum, wR / sum, wB / sum, wT / sum});

                        for (int i = 0; i < MAX_CIRCLES; i++) {
                            float[] value = new float[]{0f, 0f, 0f, 0f};
                            if (i < circles.size()) {
                                MaskCircle c = circles.get(i);
                                value = new float[]{c.x, 1f - c.y, c.rx, c.ry};
                            }
                            glProgram.setFloatsUniform("uBrush" + i, value);
                        }
                    }
                }

                glProgram.bindAttributesAndUniforms();
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e, presentationTimeUs);
            }
        }

        private void setEmptyUniforms() {
            glProgram.setFloatsUniform("uCoreRect", new float[]{0f, 0f, 0f, 0f});
            glProgram.setFloatsUniform("uOuterRect", new float[]{0f, 0f, 0f, 0f});
            glProgram.setFloatsUniform("uFeather", new float[]{1f / Math.max(1, inputWidth), 1f / Math.max(1, inputHeight)});
            glProgram.setFloatsUniform("uSideWeights", new float[]{0.25f, 0.25f, 0.25f, 0.25f});
            for (int i = 0; i < MAX_CIRCLES; i++) {
                glProgram.setFloatsUniform("uBrush" + i, new float[]{0f, 0f, 0f, 0f});
            }
        }

        private MaskKeyframe stateAt(long presentationTimeUs) {
            MaskKeyframe current = null;
            for (MaskKeyframe k : keyframes) {
                if (k.timeUs <= presentationTimeUs) current = k;
                else break;
            }
            return current;
        }

        private static ArrayList<MaskCircle> simplify(List<MaskCircle> source, int max) {
            ArrayList<MaskCircle> out = new ArrayList<>();
            if (source == null || source.isEmpty()) return out;
            if (source.size() <= max) {
                for (MaskCircle c : source) out.add(new MaskCircle(c));
                return out;
            }
            float enlarge = Math.min(1.8f, 1f + (source.size() / (float) max) * 0.12f);
            for (int i = 0; i < max; i++) {
                int index = Math.round(i * (source.size() - 1f) / Math.max(1f, max - 1f));
                MaskCircle c = source.get(index);
                out.add(new MaskCircle(c.x, c.y, c.rx * enlarge, c.ry * enlarge));
            }
            return out;
        }

        private static RectF bounds(List<MaskCircle> circles) {
            if (circles == null || circles.isEmpty()) return null;
            float left = 1f, top = 1f, right = 0f, bottom = 0f;
            for (MaskCircle c : circles) {
                left = Math.min(left, c.x - c.rx);
                top = Math.min(top, c.y - c.ry);
                right = Math.max(right, c.x + c.rx);
                bottom = Math.max(bottom, c.y + c.ry);
            }
            return new RectF(clamp01(left), clamp01(top), clamp01(right), clamp01(bottom));
        }

        @Override
        public void release() throws VideoFrameProcessingException {
            super.release();
            try {
                glProgram.delete();
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }

        private static float clamp01(float v) {
            return Math.max(0f, Math.min(1f, v));
        }
    }
}
