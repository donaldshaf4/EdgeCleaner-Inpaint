package com.edgecleaner.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.RectF;
import android.opengl.GLES20;
import android.opengl.GLUtils;

import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlProgram;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.Size;
import androidx.media3.effect.BaseGlShaderProgram;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.GlShaderProgram;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Raster-mask video restoration effect.
 *
 * Instead of reducing the freehand mask to a few circles, each keyframe uploads the exact raster
 * mask as a GL texture. The shader then searches outward from every masked pixel for nearby clean
 * pixels in several directions and blends those local samples. This avoids the large flat smear
 * caused by rectangle-wide filling and preserves small eraser corrections.
 */
public final class VideoInpaintEffect implements GlEffect {
    private final ArrayList<MaskKeyframe> keyframes;
    private final float featherPixels;
    private final float smoothStrength;

    public VideoInpaintEffect(List<MaskKeyframe> keyframes, float featherPixels, float smoothStrength) {
        this.keyframes = new ArrayList<>();
        if (keyframes != null) this.keyframes.addAll(keyframes);
        this.keyframes.sort(Comparator.comparingLong(k -> k.timeUs));
        this.featherPixels = featherPixels;
        this.smoothStrength = Math.max(0f, Math.min(1f, smoothStrength));
    }

    @Override
    public GlShaderProgram toGlShaderProgram(Context context, boolean useHdr)
            throws VideoFrameProcessingException {
        if (useHdr) throw new VideoFrameProcessingException("HDR video restoration is not supported yet.");
        return new Program(context, keyframes, featherPixels, smoothStrength);
    }

    private static final class Program extends BaseGlShaderProgram {
        private final GlProgram glProgram;
        private final ArrayList<MaskKeyframe> keyframes;
        private final float featherPixels;
        private final float smoothStrength;
        private int inputWidth;
        private int inputHeight;
        private int maskTextureId;
        private long uploadedTimeUs = Long.MIN_VALUE;
        private boolean uploadedActive;

        Program(Context context, List<MaskKeyframe> keyframes, float featherPixels, float smoothStrength)
                throws VideoFrameProcessingException {
            super(false, 1);
            this.keyframes = new ArrayList<>(keyframes);
            this.featherPixels = featherPixels;
            this.smoothStrength = Math.max(0f, Math.min(1f, smoothStrength));
            try {
                glProgram = new GlProgram(context, R.raw.vertex_shader_inpaint_es2, R.raw.fragment_shader_inpaint_es2);
                glProgram.setBufferAttribute(
                        "aFramePosition",
                        GlUtil.getNormalizedCoordinateBounds(),
                        GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE);
                float[] identity = GlUtil.create4x4IdentityMatrix();
                glProgram.setFloatsUniform("uTransformationMatrix", identity);
                glProgram.setFloatsUniform("uTexTransformationMatrix", identity);
            } catch (IOException | GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }

        @Override
        public Size configure(int inputWidth, int inputHeight) throws VideoFrameProcessingException {
            this.inputWidth = inputWidth;
            this.inputHeight = inputHeight;
            try {
                glProgram.setFloatsUniform("uTexel", new float[]{1f / inputWidth, 1f / inputHeight});
                glProgram.setFloatUniform("uSmoothStrength", smoothStrength);
                return new Size(inputWidth, inputHeight);
            } catch (RuntimeException e) {
                throw new VideoFrameProcessingException("EdgeCleaner shader configure failed", e);
            }
        }

        @Override
        public void drawFrame(int inputTexId, long presentationTimeUs)
                throws VideoFrameProcessingException {
            try {
                MaskKeyframe state = stateAt(presentationTimeUs);
                glProgram.use();
                glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0);
                ensureMaskTexture();

                boolean active = state != null && state.active && state.mask != null && state.bounds != null;
                if (!active) {
                    if (uploadedActive || uploadedTimeUs != (state == null ? Long.MIN_VALUE : state.timeUs)) {
                        uploadTransparentMask();
                        uploadedTimeUs = state == null ? Long.MIN_VALUE : state.timeUs;
                        uploadedActive = false;
                    }
                    glProgram.setFloatUniform("uEnabled", 0f);
                    glProgram.setFloatsUniform("uOuterRect", new float[]{0f, 0f, 0f, 0f});
                    glProgram.setFloatsUniform("uFeather", new float[]{1f / Math.max(1, inputWidth), 1f / Math.max(1, inputHeight)});
                    glProgram.setFloatsUniform("uSideWeights", new float[]{0.25f, 0.25f, 0.25f, 0.25f});
                } else {
                    if (!uploadedActive || uploadedTimeUs != state.timeUs) {
                        uploadMask(state.mask);
                        uploadedTimeUs = state.timeUs;
                        uploadedActive = true;
                    }

                    RectF bounds = state.bounds;
                    float pxX = 1f / Math.max(1, inputWidth);
                    float pxY = 1f / Math.max(1, inputHeight);
                    float featherX = Math.max(pxX * 1.5f, (featherPixels / inputWidth) * 0.68f);
                    float featherY = Math.max(pxY * 1.5f, (featherPixels / inputHeight) * 0.68f);
                    float expandX = Math.max(featherX * 4.0f, pxX * 12f);
                    float expandY = Math.max(featherY * 4.0f, pxY * 12f);

                    float outerLeft = clamp01(bounds.left - expandX);
                    float outerRight = clamp01(bounds.right + expandX);
                    float outerBottom = 1f - clamp01(bounds.bottom + expandY);
                    float outerTop = 1f - clamp01(bounds.top - expandY);

                    float leftSpace = Math.max(0.01f, outerLeft);
                    float rightSpace = Math.max(0.01f, 1f - outerRight);
                    float bottomSpace = Math.max(0.01f, outerBottom);
                    float topSpace = Math.max(0.01f, 1f - outerTop);
                    float wL = leftSpace * leftSpace;
                    float wR = rightSpace * rightSpace;
                    float wB = bottomSpace * bottomSpace;
                    float wT = topSpace * topSpace;
                    float sum = Math.max(0.0001f, wL + wR + wB + wT);

                    glProgram.setFloatUniform("uEnabled", 1f);
                    glProgram.setFloatsUniform("uOuterRect", new float[]{outerLeft, outerBottom, outerRight, outerTop});
                    glProgram.setFloatsUniform("uFeather", new float[]{featherX, featherY});
                    glProgram.setFloatsUniform("uSideWeights", new float[]{wL / sum, wR / sum, wB / sum, wT / sum});
                }

                glProgram.setSamplerTexIdUniform("uMaskSampler", maskTextureId, 1);
                glProgram.bindAttributesAndUniforms();
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            } catch (GlUtil.GlException | RuntimeException e) {
                throw new VideoFrameProcessingException("EdgeCleaner frame shader failed", e, presentationTimeUs);
            }
        }

        private void ensureMaskTexture() {
            if (maskTextureId != 0) return;
            int[] ids = new int[1];
            GLES20.glGenTextures(1, ids, 0);
            maskTextureId = ids[0];
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, maskTextureId);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
            uploadTransparentMask();
        }

        private void uploadTransparentMask() {
            Bitmap empty = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, maskTextureId);
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, empty, 0);
            empty.recycle();
        }

        private void uploadMask(Bitmap bitmap) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, maskTextureId);
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0);
        }

        private MaskKeyframe stateAt(long presentationTimeUs) {
            MaskKeyframe current = null;
            for (MaskKeyframe k : keyframes) {
                if (k.timeUs <= presentationTimeUs) current = k;
                else break;
            }
            return current;
        }

        @Override
        public void release() throws VideoFrameProcessingException {
            super.release();
            try {
                if (maskTextureId != 0) {
                    int[] ids = new int[]{maskTextureId};
                    GLES20.glDeleteTextures(1, ids, 0);
                    maskTextureId = 0;
                }
                glProgram.delete();
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }

        private static float clamp01(float v) {
            return Math.max(0f, Math.min(1f, v));
        }
    }
}
