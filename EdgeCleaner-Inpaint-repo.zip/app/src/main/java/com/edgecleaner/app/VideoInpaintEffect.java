package com.edgecleaner.app;

import android.content.Context;
import android.graphics.RectF;
import android.opengl.GLES20;

import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlProgram;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.Size;
import androidx.media3.effect.BaseGlShaderProgram;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.GlShaderProgram;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Time-aware video restoration effect.
 *
 * Each keyframe defines the mask state from its timestamp until the next keyframe. The shader uses
 * edge-guided multi-sampling from clean pixels outside the mask instead of mirrored coordinates,
 * avoiding the obvious reflected hands/faces created by the previous version.
 */
public final class VideoInpaintEffect implements GlEffect {
    private final ArrayList<MaskKeyframe> keyframes;
    private final float featherPixels;

    public VideoInpaintEffect(List<MaskKeyframe> keyframes, float featherPixels) {
        this.keyframes = new ArrayList<>();
        if (keyframes != null) {
            for (MaskKeyframe k : keyframes) {
                this.keyframes.add(new MaskKeyframe(k.timeUs, k.rect, k.active));
            }
        }
        this.keyframes.sort(Comparator.comparingLong(k -> k.timeUs));
        this.featherPixels = featherPixels;
    }

    @Override
    public GlShaderProgram toGlShaderProgram(Context context, boolean useHdr)
            throws VideoFrameProcessingException {
        if (useHdr) throw new VideoFrameProcessingException("HDR video restoration is not supported yet.");
        return new Program(context, keyframes, featherPixels);
    }

    private static final class Program extends BaseGlShaderProgram {
        private final GlProgram glProgram;
        private final ArrayList<MaskKeyframe> keyframes;
        private final float featherPixels;
        private int inputWidth;
        private int inputHeight;

        Program(Context context, List<MaskKeyframe> keyframes, float featherPixels)
                throws VideoFrameProcessingException {
            super(false, 1);
            this.keyframes = new ArrayList<>(keyframes);
            this.featherPixels = featherPixels;
            try {
                glProgram = new GlProgram(context, R.raw.vertex_shader_inpaint_es2, R.raw.fragment_shader_inpaint_es2);
                glProgram.setBufferAttribute(
                        "aFramePosition",
                        GlUtil.getNormalizedCoordinateBounds(),
                        GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE);
                float[] identity = GlUtil.create4x4IdentityMatrix();
                glProgram.setFloatsUniform("uTransformationMatrix", identity);
                glProgram.setFloatsUniform("uTexTransformationMatrix", identity);
            } catch (IOException | GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }

        @Override
        public Size configure(int inputWidth, int inputHeight) {
            this.inputWidth = inputWidth;
            this.inputHeight = inputHeight;
            glProgram.setFloatsUniform("uTexel", new float[]{1f / inputWidth, 1f / inputHeight});
            return new Size(inputWidth, inputHeight);
        }

        @Override
        public void drawFrame(int inputTexId, long presentationTimeUs)
                throws VideoFrameProcessingException {
            try {
                MaskKeyframe state = stateAt(presentationTimeUs);
                glProgram.use();
                glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0);

                if (state == null || !state.active || state.rect == null) {
                    glProgram.setFloatUniform("uEnabled", 0f);
                    glProgram.setFloatsUniform("uCoreRect", new float[]{0f, 0f, 0f, 0f});
                    glProgram.setFloatsUniform("uOuterRect", new float[]{0f, 0f, 0f, 0f});
                    glProgram.setFloatsUniform("uFeather", new float[]{1f / inputWidth, 1f / inputHeight});
                } else {
                    RectF r = state.rect;
                    float pxX = 1f / Math.max(1, inputWidth);
                    float pxY = 1f / Math.max(1, inputHeight);
                    float featherX = Math.max(pxX * 3f, featherPixels / inputWidth);
                    float featherY = Math.max(pxY * 3f, featherPixels / inputHeight);
                    float expandX = Math.max(featherX * 2.7f, pxX * 6f);
                    float expandY = Math.max(featherY * 2.7f, pxY * 6f);

                    float coreBottom = 1f - r.bottom;
                    float coreTop = 1f - r.top;
                    float outerLeft = clamp01(r.left - expandX);
                    float outerRight = clamp01(r.right + expandX);
                    float outerBottom = 1f - clamp01(r.bottom + expandY);
                    float outerTop = 1f - clamp01(r.top - expandY);

                    glProgram.setFloatUniform("uEnabled", 1f);
                    glProgram.setFloatsUniform("uCoreRect", new float[]{r.left, coreBottom, r.right, coreTop});
                    glProgram.setFloatsUniform("uOuterRect", new float[]{outerLeft, outerBottom, outerRight, outerTop});
                    glProgram.setFloatsUniform("uFeather", new float[]{featherX, featherY});
                }

                glProgram.bindAttributesAndUniforms();
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e, presentationTimeUs);
            }
        }

        private MaskKeyframe stateAt(long presentationTimeUs) {
            MaskKeyframe current = null;
            for (MaskKeyframe k : keyframes) {
                if (k.timeUs <= presentationTimeUs) current = k;
                else break;
            }
            return current;
        }

        @Override
        public void release() throws VideoFrameProcessingException {
            super.release();
            try {
                glProgram.delete();
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }

        private static float clamp01(float v) {
            return Math.max(0f, Math.min(1f, v));
        }
    }
}
