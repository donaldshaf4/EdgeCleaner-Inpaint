package com.edgecleaner.app;

import android.content.Context;
import android.opengl.GLES20;

import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlProgram;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.Size;
import androidx.media3.effect.BaseGlShaderProgram;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.GlShaderProgram;

import java.io.IOException;

/**
 * Lightweight local video restoration effect.
 *
 * Pixels inside the selected rectangle are reconstructed from mirrored samples around all four
 * mask edges and blended by distance. It is not a generative model, but avoids cropping and works
 * frame-by-frame inside Media3 while keeping the original audio track.
 */
public final class VideoInpaintEffect implements GlEffect {
    private final float left;
    private final float top;
    private final float right;
    private final float bottom;
    private final float featherPixels;

    public VideoInpaintEffect(float left, float top, float right, float bottom, float featherPixels) {
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
        this.featherPixels = featherPixels;
    }

    @Override
    public GlShaderProgram toGlShaderProgram(Context context, boolean useHdr)
            throws VideoFrameProcessingException {
        if (useHdr) {
            throw new VideoFrameProcessingException("HDR video restoration is not supported yet.");
        }
        return new Program(context, left, top, right, bottom, featherPixels);
    }

    private static final class Program extends BaseGlShaderProgram {
        private final GlProgram glProgram;
        private final float left;
        private final float top;
        private final float right;
        private final float bottom;
        private final float featherPixels;

        Program(Context context, float left, float top, float right, float bottom, float featherPixels)
                throws VideoFrameProcessingException {
            super(false, 1);
            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
            this.featherPixels = featherPixels;
            try {
                glProgram = new GlProgram(context, R.raw.vertex_shader_inpaint_es2, R.raw.fragment_shader_inpaint_es2);
                glProgram.setBufferAttribute(
                        "aFramePosition",
                        GlUtil.getNormalizedCoordinateBounds(),
                        GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE);
                float[] identity = GlUtil.create4x4IdentityMatrix();
                glProgram.setFloatsUniform("uTransformationMatrix", identity);
                glProgram.setFloatsUniform("uTexTransformationMatrix", identity);
            } catch (IOException | GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }

        @Override
        public Size configure(int inputWidth, int inputHeight) throws VideoFrameProcessingException {
            // UI coordinates are top-left based; OpenGL texture coordinates are bottom-left based.
            float glBottom = 1f - bottom;
            float glTop = 1f - top;
            float featherX = Math.max(1f / inputWidth, featherPixels / inputWidth);
            float featherY = Math.max(1f / inputHeight, featherPixels / inputHeight);
            glProgram.setFloatsUniform("uMaskRect", new float[]{left, glBottom, right, glTop});
            glProgram.setFloatsUniform("uFeather", new float[]{featherX, featherY});
            return new Size(inputWidth, inputHeight);
        }

        @Override
        public void drawFrame(int inputTexId, long presentationTimeUs)
                throws VideoFrameProcessingException {
            try {
                glProgram.use();
                glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0);
                glProgram.bindAttributesAndUniforms();
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e, presentationTimeUs);
            }
        }

        @Override
        public void release() throws VideoFrameProcessingException {
            super.release();
            try {
                glProgram.delete();
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }
    }
}
