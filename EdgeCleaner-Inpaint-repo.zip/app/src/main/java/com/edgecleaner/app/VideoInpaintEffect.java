package com.edgecleaner.app;

import android.content.Context;
import android.opengl.GLES20;

import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlProgram;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.Size;
import androidx.media3.effect.BaseGlShaderProgram;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.GlShaderProgram;

import java.io.IOException;

/**
 * Lightweight local video restoration effect.
 *
 * The selected rectangle is treated as the watermark area (core rect). The shader also builds
 * a slightly larger outer rect around it and blends from original -> restored only in that ring,
 * which makes the transition much softer than a hard rectangle. Restoration itself uses multiple
 * samples from outside the masked area, averaged along the edge tangents to reduce obvious mirror
 * seams and "copied neighbour" reflections.
 */
public final class VideoInpaintEffect implements GlEffect {
    private final float left;
    private final float top;
    private final float right;
    private final float bottom;
    private final float featherPixels;

    public VideoInpaintEffect(float left, float top, float right, float bottom, float featherPixels) {
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
        this.featherPixels = featherPixels;
    }

    @Override
    public GlShaderProgram toGlShaderProgram(Context context, boolean useHdr)
            throws VideoFrameProcessingException {
        if (useHdr) {
            throw new VideoFrameProcessingException("HDR video restoration is not supported yet.");
        }
        return new Program(context, left, top, right, bottom, featherPixels);
    }

    private static final class Program extends BaseGlShaderProgram {
        private final GlProgram glProgram;
        private final float left;
        private final float top;
        private final float right;
        private final float bottom;
        private final float featherPixels;

        Program(Context context, float left, float top, float right, float bottom, float featherPixels)
                throws VideoFrameProcessingException {
            super(false, 1);
            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
            this.featherPixels = featherPixels;
            try {
                glProgram = new GlProgram(context, R.raw.vertex_shader_inpaint_es2, R.raw.fragment_shader_inpaint_es2);
                glProgram.setBufferAttribute(
                        "aFramePosition",
                        GlUtil.getNormalizedCoordinateBounds(),
                        GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE);
                float[] identity = GlUtil.create4x4IdentityMatrix();
                glProgram.setFloatsUniform("uTransformationMatrix", identity);
                glProgram.setFloatsUniform("uTexTransformationMatrix", identity);
            } catch (IOException | GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }

        @Override
        public Size configure(int inputWidth, int inputHeight) throws VideoFrameProcessingException {
            // UI coordinates are top-left based; OpenGL texture coordinates are bottom-left based.
            float glCoreBottom = 1f - bottom;
            float glCoreTop = 1f - top;

            float pxX = 1f / Math.max(1, inputWidth);
            float pxY = 1f / Math.max(1, inputHeight);
            float featherX = Math.max(pxX * 2f, featherPixels / inputWidth);
            float featherY = Math.max(pxY * 2f, featherPixels / inputHeight);

            // Expand the edited area a little so the transition happens outside the actual
            // watermark rectangle. This hides the visible border better.
            float expandX = Math.max(featherX * 2.5f, pxX * 4f);
            float expandY = Math.max(featherY * 2.5f, pxY * 4f);
            float outerLeft = clamp01(left - expandX);
            float outerRight = clamp01(right + expandX);
            float outerTopUi = clamp01(top - expandY);
            float outerBottomUi = clamp01(bottom + expandY);
            float glOuterBottom = 1f - outerBottomUi;
            float glOuterTop = 1f - outerTopUi;

            // Tangential sampling spread to reduce repeated seam patterns.
            float sampleSpreadX = Math.max(featherX * 1.8f, pxX * 3f);
            float sampleSpreadY = Math.max(featherY * 1.8f, pxY * 3f);

            glProgram.setFloatsUniform("uCoreRect", new float[]{left, glCoreBottom, right, glCoreTop});
            glProgram.setFloatsUniform("uOuterRect", new float[]{outerLeft, glOuterBottom, outerRight, glOuterTop});
            glProgram.setFloatsUniform("uFeather", new float[]{featherX, featherY});
            glProgram.setFloatsUniform("uSampleSpread", new float[]{sampleSpreadX, sampleSpreadY});
            return new Size(inputWidth, inputHeight);
        }

        @Override
        public void drawFrame(int inputTexId, long presentationTimeUs)
                throws VideoFrameProcessingException {
            try {
                glProgram.use();
                glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0);
                glProgram.bindAttributesAndUniforms();
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e, presentationTimeUs);
            }
        }

        @Override
        public void release() throws VideoFrameProcessingException {
            super.release();
            try {
                glProgram.delete();
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }

        private static float clamp01(float v) {
            return Math.max(0f, Math.min(1f, v));
        }
    }
}
