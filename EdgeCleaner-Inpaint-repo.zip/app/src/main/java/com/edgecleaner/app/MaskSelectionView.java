package com.edgecleaner.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Freehand brush mask constrained to the displayed media bounds. */
public final class MaskSelectionView extends View {
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint outlinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF contentRect = new RectF();
    private final ArrayList<MaskCircle> circles = new ArrayList<>();

    private float contentAspect = 16f / 9f;
    private float brushDp = 24f;
    private float lastX;
    private float lastY;
    private boolean drawing;

    public MaskSelectionView(Context context) {
        super(context);
        setWillNotDraw(false);
        setClickable(true);
        setFocusable(true);

        fillPaint.setStyle(Paint.Style.FILL);
        fillPaint.setColor(0x66FF3D00);
        outlinePaint.setStyle(Paint.Style.STROKE);
        outlinePaint.setStrokeWidth(dp(1.5f));
        outlinePaint.setColor(Color.WHITE);
    }

    public void setContentSize(int width, int height) {
        if (width > 0 && height > 0) {
            contentAspect = width / (float) height;
            updateContentRect();
            clearMask();
            invalidate();
        }
    }

    public void setBrushSizeDp(float value) {
        brushDp = Math.max(8f, Math.min(64f, value));
        invalidate();
    }

    public void clearMask() {
        circles.clear();
        invalidate();
    }

    public boolean hasMask() {
        return !circles.isEmpty();
    }

    public ArrayList<MaskCircle> getNormalizedCircles(int maxCircles) {
        ArrayList<MaskCircle> out = new ArrayList<>();
        if (circles.isEmpty() || maxCircles <= 0) return out;
        if (circles.size() <= maxCircles) {
            for (MaskCircle c : circles) out.add(new MaskCircle(c));
            return out;
        }

        // Evenly sample the stroke and slightly enlarge the kept dabs to preserve coverage.
        float enlarge = Math.min(1.8f, 1f + (circles.size() / (float) maxCircles) * 0.12f);
        for (int i = 0; i < maxCircles; i++) {
            int index = Math.round(i * (circles.size() - 1f) / Math.max(1f, maxCircles - 1f));
            MaskCircle c = circles.get(index);
            out.add(new MaskCircle(c.x, c.y, c.rx * enlarge, c.ry * enlarge));
        }
        return out;
    }

    public ArrayList<MaskCircle> getNormalizedCircles() {
        ArrayList<MaskCircle> out = new ArrayList<>();
        for (MaskCircle c : circles) out.add(new MaskCircle(c));
        return out;
    }

    public void setNormalizedCircles(List<MaskCircle> values) {
        circles.clear();
        if (values != null) {
            for (MaskCircle c : values) circles.add(new MaskCircle(c));
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        updateContentRect();
        if (contentRect.isEmpty() || circles.isEmpty()) return;

        canvas.save();
        canvas.clipRect(contentRect);
        for (MaskCircle c : circles) {
            float cx = contentRect.left + c.x * contentRect.width();
            float cy = contentRect.top + c.y * contentRect.height();
            float rx = c.rx * contentRect.width();
            float ry = c.ry * contentRect.height();
            RectF oval = new RectF(cx - rx, cy - ry, cx + rx, cy + ry);
            canvas.drawOval(oval, fillPaint);
            canvas.drawOval(oval, outlinePaint);
        }
        canvas.restore();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled()) return false;
        updateContentRect();
        if (contentRect.isEmpty()) return false;

        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            if (!contentRect.contains(event.getX(), event.getY())) return false;
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            drawing = true;
            lastX = event.getX();
            lastY = event.getY();
            addDab(lastX, lastY);
            invalidate();
            return true;
        }

        if (!drawing) return false;
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);

        switch (action) {
            case MotionEvent.ACTION_MOVE:
                float x = clamp(event.getX(), contentRect.left, contentRect.right);
                float y = clamp(event.getY(), contentRect.top, contentRect.bottom);
                float spacing = dp(brushDp) * 0.42f;
                float dx = x - lastX;
                float dy = y - lastY;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                if (dist >= spacing) {
                    int steps = Math.max(1, (int) (dist / spacing));
                    for (int i = 1; i <= steps; i++) {
                        float f = i / (float) steps;
                        addDab(lastX + dx * f, lastY + dy * f);
                    }
                    lastX = x;
                    lastY = y;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
                drawing = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                performClick();
                invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
                drawing = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                return true;
            default:
                return true;
        }
    }

    private void addDab(float x, float y) {
        if (!contentRect.contains(x, y)) return;
        float radiusPx = dp(brushDp) * 0.5f;
        float nx = (x - contentRect.left) / contentRect.width();
        float ny = (y - contentRect.top) / contentRect.height();
        float rx = radiusPx / contentRect.width();
        float ry = radiusPx / contentRect.height();
        circles.add(new MaskCircle(nx, ny, rx, ry));
        // Avoid unbounded memory during long strokes; video export uses at most 8 simplified dabs.
        if (circles.size() > 240) circles.remove(0);
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private void updateContentRect() {
        float vw = getWidth();
        float vh = getHeight();
        if (vw <= 0 || vh <= 0 || contentAspect <= 0f) {
            contentRect.setEmpty();
            return;
        }
        float viewAspect = vw / vh;
        if (contentAspect > viewAspect) {
            float h = vw / contentAspect;
            float top = (vh - h) / 2f;
            contentRect.set(0f, top, vw, top + h);
        } else {
            float w = vh * contentAspect;
            float left = (vw - w) / 2f;
            contentRect.set(left, 0f, left + w, vh);
        }
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
