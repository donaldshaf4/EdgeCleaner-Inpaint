package com.edgecleaner.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * Freehand brush mask constrained to the displayed media bounds.
 *
 * The overlay is drawn as a continuous round stroke (not visible separate circles), and a custom
 * loupe is rendered from the current preview bitmap so the user sees the exact area under the
 * finger.
 */
public final class MaskSelectionView extends View {
    private final Paint maskGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint maskStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint eraseCursorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cursorDarkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cursorLightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint loupeBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint loupeBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint loupeCrossPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF contentRect = new RectF();
    private final ArrayList<MaskCircle> circles = new ArrayList<>();
    private final Path loupeClipPath = new Path();
    private final RectF dstRect = new RectF();

    private float contentAspect = 16f / 9f;
    private float brushDp = 24f;
    private float lastX;
    private float lastY;
    private float touchX;
    private float touchY;
    private boolean drawing;
    private boolean eraseMode;
    private Bitmap previewBitmap;
    private Runnable brushStartListener;

    public MaskSelectionView(Context context) {
        super(context);
        setWillNotDraw(false);
        setClickable(true);
        setFocusable(true);

        maskGlowPaint.setStyle(Paint.Style.STROKE);
        maskGlowPaint.setColor(0x66FF855E);
        maskGlowPaint.setStrokeCap(Paint.Cap.ROUND);
        maskGlowPaint.setStrokeJoin(Paint.Join.ROUND);

        maskStrokePaint.setStyle(Paint.Style.STROKE);
        maskStrokePaint.setColor(0xA6FF5A36);
        maskStrokePaint.setStrokeCap(Paint.Cap.ROUND);
        maskStrokePaint.setStrokeJoin(Paint.Join.ROUND);

        cursorDarkPaint.setStyle(Paint.Style.STROKE);
        cursorDarkPaint.setStrokeWidth(dp(3f));
        cursorDarkPaint.setColor(0xAA000000);
        cursorLightPaint.setStyle(Paint.Style.STROKE);
        cursorLightPaint.setStrokeWidth(dp(1.5f));
        cursorLightPaint.setColor(Color.WHITE);

        eraseCursorPaint.setStyle(Paint.Style.STROKE);
        eraseCursorPaint.setStrokeWidth(dp(1.5f));
        eraseCursorPaint.setColor(0xFF7FDBFF);

        loupeBgPaint.setStyle(Paint.Style.FILL);
        loupeBgPaint.setColor(0xF2FFFFFF);
        loupeBorderPaint.setStyle(Paint.Style.STROKE);
        loupeBorderPaint.setStrokeWidth(dp(2f));
        loupeBorderPaint.setColor(0xE6FFFFFF);
        loupeCrossPaint.setStyle(Paint.Style.STROKE);
        loupeCrossPaint.setStrokeWidth(dp(1.5f));
        loupeCrossPaint.setColor(0xCCFFFFFF);
    }

    public void setOnBrushStartListener(Runnable listener) {
        brushStartListener = listener;
    }

    public void setContentSize(int width, int height) {
        if (width > 0 && height > 0) {
            contentAspect = width / (float) height;
            updateContentRect();
            clearMask();
            invalidate();
        }
    }

    public void setPreviewBitmap(Bitmap bitmap) {
        previewBitmap = bitmap;
        invalidate();
    }

    public Bitmap getPreviewBitmap() {
        return previewBitmap;
    }

    public void setBrushSizeDp(float value) {
        brushDp = Math.max(8f, Math.min(64f, value));
        invalidate();
    }

    public float getBrushSizeDp() {
        return brushDp;
    }

    public void setEraseMode(boolean value) {
        eraseMode = value;
        invalidate();
    }

    public boolean isEraseMode() {
        return eraseMode;
    }

    public void clearMask() {
        circles.clear();
        invalidate();
    }

    public boolean hasMask() {
        return !circles.isEmpty();
    }

    public ArrayList<MaskCircle> getNormalizedCircles(int maxCircles) {
        ArrayList<MaskCircle> out = new ArrayList<>();
        if (circles.isEmpty() || maxCircles <= 0) return out;
        if (circles.size() <= maxCircles) {
            for (MaskCircle c : circles) out.add(new MaskCircle(c));
            return out;
        }

        float enlarge = Math.min(1.07f, 1f + Math.max(0f, circles.size() / (float) maxCircles - 1f) * 0.015f);
        for (int i = 0; i < maxCircles; i++) {
            int index = Math.round(i * (circles.size() - 1f) / Math.max(1f, maxCircles - 1f));
            MaskCircle c = circles.get(index);
            out.add(new MaskCircle(c.x, c.y, c.rx * enlarge, c.ry * enlarge));
        }
        return out;
    }

    public ArrayList<MaskCircle> getNormalizedCircles() {
        ArrayList<MaskCircle> out = new ArrayList<>();
        for (MaskCircle c : circles) out.add(new MaskCircle(c));
        return out;
    }

    public void setNormalizedCircles(List<MaskCircle> values) {
        circles.clear();
        if (values != null) {
            for (MaskCircle c : values) circles.add(new MaskCircle(c));
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        updateContentRect();
        if (contentRect.isEmpty()) return;

        canvas.save();
        canvas.clipRect(contentRect);
        drawMaskStroke(canvas);
        if (drawing) {
            float radiusPx = dp(brushDp) * 0.5f;
            if (eraseMode) {
                canvas.drawCircle(touchX, touchY, radiusPx + dp(1f), cursorDarkPaint);
                canvas.drawCircle(touchX, touchY, radiusPx, eraseCursorPaint);
                canvas.drawLine(touchX - radiusPx * 0.55f, touchY, touchX + radiusPx * 0.55f, touchY, eraseCursorPaint);
            } else {
                canvas.drawCircle(touchX, touchY, radiusPx + dp(1f), cursorDarkPaint);
                canvas.drawCircle(touchX, touchY, radiusPx, cursorLightPaint);
            }
        }
        canvas.restore();

        if (drawing) {
            drawLoupe(canvas);
        }
    }

    private void drawMaskStroke(Canvas canvas) {
        if (circles.isEmpty()) return;
        float avgRadiusPx = 0f;
        for (MaskCircle c : circles) avgRadiusPx += (c.rx * contentRect.width() + c.ry * contentRect.height()) * 0.25f;
        avgRadiusPx = Math.max(dp(brushDp) * 0.5f, avgRadiusPx / circles.size());

        maskGlowPaint.setStrokeWidth(avgRadiusPx * 2.28f);
        maskStrokePaint.setStrokeWidth(avgRadiusPx * 2f);

        if (circles.size() == 1) {
            float cx = contentRect.left + circles.get(0).x * contentRect.width();
            float cy = contentRect.top + circles.get(0).y * contentRect.height();
            canvas.drawCircle(cx, cy, avgRadiusPx * 1.08f, maskGlowPaint);
            canvas.drawCircle(cx, cy, avgRadiusPx, maskStrokePaint);
            return;
        }

        float prevCx = 0f, prevCy = 0f;
        for (int i = 0; i < circles.size(); i++) {
            MaskCircle c = circles.get(i);
            float cx = contentRect.left + c.x * contentRect.width();
            float cy = contentRect.top + c.y * contentRect.height();
            if (i > 0) {
                canvas.drawLine(prevCx, prevCy, cx, cy, maskGlowPaint);
                canvas.drawLine(prevCx, prevCy, cx, cy, maskStrokePaint);
            }
            prevCx = cx;
            prevCy = cy;
        }
    }

    private void drawLoupe(Canvas canvas) {
        if (previewBitmap == null || previewBitmap.isRecycled()) return;

        float loupeW = dp(168f);
        float loupeH = dp(108f);
        float margin = dp(12f);
        float verticalGap = dp(78f);

        float left = touchX - loupeW * 0.5f;
        left = clamp(left, margin, Math.max(margin, getWidth() - loupeW - margin));

        boolean showAbove = touchY > contentRect.centerY();
        float top = showAbove ? touchY - loupeH - verticalGap : touchY + verticalGap;
        if (top < margin) top = touchY + verticalGap;
        if (top + loupeH > getHeight() - margin) top = touchY - loupeH - verticalGap;
        top = clamp(top, margin, Math.max(margin, getHeight() - loupeH - margin));
        dstRect.set(left, top, left + loupeW, top + loupeH);

        float nx = clamp((touchX - contentRect.left) / Math.max(1f, contentRect.width()), 0f, 1f);
        float ny = clamp((touchY - contentRect.top) / Math.max(1f, contentRect.height()), 0f, 1f);
        float sourceX = nx * previewBitmap.getWidth();
        float sourceY = ny * previewBitmap.getHeight();

        float sourceWindowW = Math.max(48f, previewBitmap.getWidth() / 4.8f);
        float sourceWindowH = sourceWindowW * (loupeH / loupeW);
        sourceWindowH = Math.min(sourceWindowH, Math.max(36f, previewBitmap.getHeight() / 2.2f));
        float scale = Math.min(loupeW / sourceWindowW, loupeH / sourceWindowH);

        float radius = dp(24f);
        canvas.drawRoundRect(dstRect, radius, radius, loupeBgPaint);
        loupeClipPath.reset();
        loupeClipPath.addRoundRect(dstRect, radius, radius, Path.Direction.CW);

        float cx = dstRect.centerX();
        float cy = dstRect.centerY();
        canvas.save();
        canvas.clipPath(loupeClipPath);
        canvas.drawColor(0xFF15181C);
        canvas.translate(cx - sourceX * scale, cy - sourceY * scale);
        canvas.scale(scale, scale);
        canvas.drawBitmap(previewBitmap, 0f, 0f, null);
        canvas.restore();

        canvas.drawRoundRect(dstRect, radius, radius, loupeBorderPaint);
        canvas.drawLine(cx - dp(18f), cy, cx + dp(18f), cy, loupeCrossPaint);
        canvas.drawLine(cx, cy - dp(18f), cx, cy + dp(18f), loupeCrossPaint);

        float bitmapBrushRadius = (dp(brushDp) * 0.5f / Math.max(1f, contentRect.width())) * previewBitmap.getWidth();
        float loupeBrushRadius = Math.max(dp(5f), bitmapBrushRadius * scale);
        if (eraseMode) {
            canvas.drawCircle(cx, cy, loupeBrushRadius + dp(1f), cursorDarkPaint);
            canvas.drawCircle(cx, cy, loupeBrushRadius, eraseCursorPaint);
            canvas.drawLine(cx - loupeBrushRadius * 0.55f, cy, cx + loupeBrushRadius * 0.55f, cy, eraseCursorPaint);
        } else {
            canvas.drawCircle(cx, cy, loupeBrushRadius + dp(1f), cursorDarkPaint);
            canvas.drawCircle(cx, cy, loupeBrushRadius, cursorLightPaint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled()) return false;
        updateContentRect();
        if (contentRect.isEmpty()) return false;

        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            if (!contentRect.contains(event.getX(), event.getY())) return false;
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            if (brushStartListener != null) brushStartListener.run();
            drawing = true;
            lastX = event.getX();
            lastY = event.getY();
            touchX = lastX;
            touchY = lastY;
            applyBrush(lastX, lastY);
            invalidate();
            return true;
        }

        if (!drawing) return false;
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);

        switch (action) {
            case MotionEvent.ACTION_MOVE:
                float x = clamp(event.getX(), contentRect.left, contentRect.right);
                float y = clamp(event.getY(), contentRect.top, contentRect.bottom);
                touchX = x;
                touchY = y;
                float spacing = Math.max(dp(brushDp) * 0.24f, dp(2.2f));
                float dx = x - lastX;
                float dy = y - lastY;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                if (dist >= spacing) {
                    int steps = Math.max(1, (int) (dist / spacing));
                    for (int i = 1; i <= steps; i++) {
                        float f = i / (float) steps;
                        applyBrush(lastX + dx * f, lastY + dy * f);
                    }
                    lastX = x;
                    lastY = y;
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                drawing = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                performClick();
                invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
                drawing = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                invalidate();
                return true;
            default:
                return true;
        }
    }

    private void applyBrush(float x, float y) {
        if (eraseMode) eraseDab(x, y);
        else addDab(x, y);
    }

    private void addDab(float x, float y) {
        if (!contentRect.contains(x, y)) return;
        float radiusPx = dp(brushDp) * 0.5f;
        float nx = (x - contentRect.left) / contentRect.width();
        float ny = (y - contentRect.top) / contentRect.height();
        float rx = radiusPx / contentRect.width();
        float ry = radiusPx / contentRect.height();

        if (!circles.isEmpty()) {
            MaskCircle last = circles.get(circles.size() - 1);
            float px = contentRect.left + last.x * contentRect.width();
            float py = contentRect.top + last.y * contentRect.height();
            if (Math.hypot(x - px, y - py) < radiusPx * 0.22f) return;
        }

        circles.add(new MaskCircle(nx, ny, rx, ry));
        if (circles.size() > 320) circles.remove(0);
    }

    private void eraseDab(float x, float y) {
        if (!contentRect.contains(x, y)) return;
        float nx = (x - contentRect.left) / contentRect.width();
        float ny = (y - contentRect.top) / contentRect.height();
        float erx = (dp(brushDp) * 0.6f) / contentRect.width();
        float ery = (dp(brushDp) * 0.6f) / contentRect.height();
        for (int i = circles.size() - 1; i >= 0; i--) {
            MaskCircle c = circles.get(i);
            float dx = (c.x - nx) / Math.max(0.0001f, c.rx + erx);
            float dy = (c.y - ny) / Math.max(0.0001f, c.ry + ery);
            if (dx * dx + dy * dy <= 1.0f) circles.remove(i);
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private void updateContentRect() {
        float vw = getWidth();
        float vh = getHeight();
        if (vw <= 0 || vh <= 0 || contentAspect <= 0f) {
            contentRect.setEmpty();
            return;
        }
        float viewAspect = vw / vh;
        if (contentAspect > viewAspect) {
            float h = vw / contentAspect;
            float top = (vh - h) / 2f;
            contentRect.set(0f, top, vw, top + h);
        } else {
            float w = vh * contentAspect;
            float left = (vw - w) / 2f;
            contentRect.set(left, 0f, left + w, vh);
        }
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
