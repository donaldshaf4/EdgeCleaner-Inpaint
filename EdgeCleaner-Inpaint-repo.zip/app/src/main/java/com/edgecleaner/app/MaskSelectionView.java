package com.edgecleaner.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.List;

/** Exact raster brush/eraser mask with an on-screen loupe. */
public final class MaskSelectionView extends View {
    private static final int MASK_LONG_SIDE = 720;

    private final Paint overlayPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint drawPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint erasePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint eraseCursorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cursorDarkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cursorLightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint loupeBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint loupeBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint loupeCrossPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF contentRect = new RectF();
    private final Path loupeClipPath = new Path();
    private final RectF dstRect = new RectF();

    private int mediaWidth = 16;
    private int mediaHeight = 9;
    private float contentAspect = 16f / 9f;
    private float brushDp = 18f;
    private float eraseBrushDp = 7f;
    private float lastMaskX;
    private float lastMaskY;
    private float touchX;
    private float touchY;
    private boolean drawing;
    private boolean eraseMode;
    private Bitmap previewBitmap;
    private Bitmap maskBitmap;
    private Canvas maskCanvas;
    private Runnable brushStartListener;

    public MaskSelectionView(Context context) {
        super(context);
        setWillNotDraw(false);
        setClickable(true);
        setFocusable(true);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        overlayPaint.setColorFilter(new PorterDuffColorFilter(0xB3FF6540, PorterDuff.Mode.SRC_IN));

        drawPaint.setStyle(Paint.Style.STROKE);
        drawPaint.setStrokeCap(Paint.Cap.ROUND);
        drawPaint.setStrokeJoin(Paint.Join.ROUND);
        drawPaint.setColor(Color.WHITE);
        drawPaint.setDither(true);

        erasePaint.setStyle(Paint.Style.STROKE);
        erasePaint.setStrokeCap(Paint.Cap.ROUND);
        erasePaint.setStrokeJoin(Paint.Join.ROUND);
        erasePaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));

        cursorDarkPaint.setStyle(Paint.Style.STROKE);
        cursorDarkPaint.setStrokeWidth(dp(3f));
        cursorDarkPaint.setColor(0xAA000000);
        cursorLightPaint.setStyle(Paint.Style.STROKE);
        cursorLightPaint.setStrokeWidth(dp(1.5f));
        cursorLightPaint.setColor(Color.WHITE);
        eraseCursorPaint.setStyle(Paint.Style.STROKE);
        eraseCursorPaint.setStrokeWidth(dp(1.7f));
        eraseCursorPaint.setColor(0xFF66D9FF);

        loupeBgPaint.setStyle(Paint.Style.FILL);
        loupeBgPaint.setColor(0xF2FFFFFF);
        loupeBorderPaint.setStyle(Paint.Style.STROKE);
        loupeBorderPaint.setStrokeWidth(dp(2f));
        loupeBorderPaint.setColor(0xE6FFFFFF);
        loupeCrossPaint.setStyle(Paint.Style.STROKE);
        loupeCrossPaint.setStrokeWidth(dp(1.5f));
        loupeCrossPaint.setColor(0xCCFFFFFF);

        recreateMaskBitmap();
    }

    public void setOnBrushStartListener(Runnable listener) {
        brushStartListener = listener;
    }

    public void setContentSize(int width, int height) {
        if (width > 0 && height > 0) {
            mediaWidth = width;
            mediaHeight = height;
            contentAspect = width / (float) height;
            updateContentRect();
            recreateMaskBitmap();
            invalidate();
        }
    }

    public void setPreviewBitmap(Bitmap bitmap) {
        previewBitmap = bitmap;
        invalidate();
    }

    public Bitmap getPreviewBitmap() {
        return previewBitmap;
    }

    public void setBrushSizeDp(float value) {
        brushDp = Math.max(3f, Math.min(64f, value));
        invalidate();
    }

    public float getBrushSizeDp() {
        return brushDp;
    }

    public void setEraseBrushSizeDp(float value) {
        eraseBrushDp = Math.max(2f, Math.min(40f, value));
        invalidate();
    }

    public float getEraseBrushSizeDp() {
        return eraseBrushDp;
    }

    public void setEraseMode(boolean value) {
        eraseMode = value;
        invalidate();
    }

    public boolean isEraseMode() {
        return eraseMode;
    }

    public void clearMask() {
        ensureMaskBitmap();
        maskCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        invalidate();
    }

    public boolean hasMask() {
        return findBounds(maskBitmap) != null;
    }

    public Bitmap getMaskBitmapCopy() {
        if (!hasMask()) return null;
        return maskBitmap.copy(Bitmap.Config.ARGB_8888, false);
    }

    public void setMaskBitmap(Bitmap source) {
        ensureMaskBitmap();
        maskCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        if (source != null && !source.isRecycled()) {
            RectF dst = new RectF(0, 0, maskBitmap.getWidth(), maskBitmap.getHeight());
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            maskCanvas.drawBitmap(source, null, dst, p);
        }
        invalidate();
    }

    /** Compatibility helper used by the automatic detector. */
    public void setNormalizedCircles(List<MaskCircle> values) {
        clearMask();
        if (values == null || values.isEmpty()) return;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);

        MaskCircle prev = null;
        for (MaskCircle c : values) {
            float x = c.x * maskBitmap.getWidth();
            float y = c.y * maskBitmap.getHeight();
            float r = Math.max(c.rx * maskBitmap.getWidth(), c.ry * maskBitmap.getHeight());
            p.setStrokeWidth(Math.max(2f, r * 2f));
            if (prev == null) {
                maskCanvas.drawPoint(x, y, p);
            } else {
                float px = prev.x * maskBitmap.getWidth();
                float py = prev.y * maskBitmap.getHeight();
                float gap = (float) Math.hypot(x - px, y - py);
                if (gap < Math.max(8f, r * 5f)) maskCanvas.drawLine(px, py, x, y, p);
                else maskCanvas.drawPoint(x, y, p);
            }
            prev = c;
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        updateContentRect();
        if (contentRect.isEmpty()) return;

        ensureMaskBitmap();
        canvas.save();
        canvas.clipRect(contentRect);
        canvas.drawBitmap(maskBitmap, null, contentRect, overlayPaint);
        if (drawing) {
            float radiusPx = currentRadiusPx();
            canvas.drawCircle(touchX, touchY, radiusPx + dp(1f), cursorDarkPaint);
            canvas.drawCircle(touchX, touchY, radiusPx, eraseMode ? eraseCursorPaint : cursorLightPaint);
            if (eraseMode) {
                canvas.drawLine(touchX - radiusPx * 0.55f, touchY,
                        touchX + radiusPx * 0.55f, touchY, eraseCursorPaint);
            }
        }
        canvas.restore();

        if (drawing) drawLoupe(canvas);
    }

    private void drawLoupe(Canvas canvas) {
        if (previewBitmap == null || previewBitmap.isRecycled()) return;

        float loupeW = dp(168f);
        float loupeH = dp(108f);
        float margin = dp(12f);
        float verticalGap = dp(82f);

        float left = clamp(touchX - loupeW * 0.5f, margin,
                Math.max(margin, getWidth() - loupeW - margin));
        boolean showAbove = touchY > contentRect.centerY();
        float top = showAbove ? touchY - loupeH - verticalGap : touchY + verticalGap;
        if (top < margin) top = touchY + verticalGap;
        if (top + loupeH > getHeight() - margin) top = touchY - loupeH - verticalGap;
        top = clamp(top, margin, Math.max(margin, getHeight() - loupeH - margin));
        dstRect.set(left, top, left + loupeW, top + loupeH);

        float nx = clamp((touchX - contentRect.left) / Math.max(1f, contentRect.width()), 0f, 1f);
        float ny = clamp((touchY - contentRect.top) / Math.max(1f, contentRect.height()), 0f, 1f);
        float sourceX = nx * previewBitmap.getWidth();
        float sourceY = ny * previewBitmap.getHeight();

        float sourceWindowW = Math.max(44f, previewBitmap.getWidth() / 4.8f);
        float sourceWindowH = sourceWindowW * (loupeH / loupeW);
        sourceWindowH = Math.min(sourceWindowH, Math.max(32f, previewBitmap.getHeight() / 2.0f));
        float scale = Math.min(loupeW / sourceWindowW, loupeH / sourceWindowH);

        float radius = dp(24f);
        canvas.drawRoundRect(dstRect, radius, radius, loupeBgPaint);
        loupeClipPath.reset();
        loupeClipPath.addRoundRect(dstRect, radius, radius, Path.Direction.CW);

        float cx = dstRect.centerX();
        float cy = dstRect.centerY();
        canvas.save();
        canvas.clipPath(loupeClipPath);
        canvas.drawColor(0xFF15181C);
        canvas.translate(cx - sourceX * scale, cy - sourceY * scale);
        canvas.scale(scale, scale);
        canvas.drawBitmap(previewBitmap, 0f, 0f, null);
        canvas.restore();

        canvas.drawRoundRect(dstRect, radius, radius, loupeBorderPaint);
        canvas.drawLine(cx - dp(18f), cy, cx + dp(18f), cy, loupeCrossPaint);
        canvas.drawLine(cx, cy - dp(18f), cx, cy + dp(18f), loupeCrossPaint);

        float bitmapBrushRadius = (currentRadiusPx() / Math.max(1f, contentRect.width()))
                * previewBitmap.getWidth();
        float loupeBrushRadius = Math.max(dp(4f), bitmapBrushRadius * scale);
        canvas.drawCircle(cx, cy, loupeBrushRadius + dp(1f), cursorDarkPaint);
        canvas.drawCircle(cx, cy, loupeBrushRadius, eraseMode ? eraseCursorPaint : cursorLightPaint);
        if (eraseMode) {
            canvas.drawLine(cx - loupeBrushRadius * 0.55f, cy,
                    cx + loupeBrushRadius * 0.55f, cy, eraseCursorPaint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled()) return false;
        updateContentRect();
        if (contentRect.isEmpty()) return false;
        ensureMaskBitmap();

        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            if (!contentRect.contains(event.getX(), event.getY())) return false;
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            if (brushStartListener != null) brushStartListener.run();
            drawing = true;
            touchX = event.getX();
            touchY = event.getY();
            float[] mp = toMaskPoint(touchX, touchY);
            lastMaskX = mp[0];
            lastMaskY = mp[1];
            drawMaskPoint(lastMaskX, lastMaskY);
            invalidate();
            return true;
        }

        if (!drawing) return false;
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);

        switch (action) {
            case MotionEvent.ACTION_MOVE:
                touchX = clamp(event.getX(), contentRect.left, contentRect.right);
                touchY = clamp(event.getY(), contentRect.top, contentRect.bottom);
                float[] mp = toMaskPoint(touchX, touchY);
                drawMaskLine(lastMaskX, lastMaskY, mp[0], mp[1]);
                lastMaskX = mp[0];
                lastMaskY = mp[1];
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                drawing = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                performClick();
                invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
                drawing = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                invalidate();
                return true;
            default:
                return true;
        }
    }

    private void drawMaskPoint(float x, float y) {
        Paint p = activeMaskPaint();
        float radius = maskStrokeWidth() * 0.5f;
        if (eraseMode) maskCanvas.drawCircle(x, y, radius, p);
        else maskCanvas.drawCircle(x, y, radius, p);
    }

    private void drawMaskLine(float x1, float y1, float x2, float y2) {
        Paint p = activeMaskPaint();
        maskCanvas.drawLine(x1, y1, x2, y2, p);
    }

    private Paint activeMaskPaint() {
        Paint p = eraseMode ? erasePaint : drawPaint;
        p.setStrokeWidth(maskStrokeWidth());
        return p;
    }

    private float maskStrokeWidth() {
        float dpValue = eraseMode ? eraseBrushDp : brushDp;
        float px = dp(dpValue);
        return Math.max(1f, px / Math.max(1f, contentRect.width()) * maskBitmap.getWidth());
    }

    private float[] toMaskPoint(float x, float y) {
        float nx = clamp((x - contentRect.left) / Math.max(1f, contentRect.width()), 0f, 1f);
        float ny = clamp((y - contentRect.top) / Math.max(1f, contentRect.height()), 0f, 1f);
        return new float[]{nx * maskBitmap.getWidth(), ny * maskBitmap.getHeight()};
    }

    private void recreateMaskBitmap() {
        if (mediaWidth <= 0 || mediaHeight <= 0) return;
        int w;
        int h;
        if (mediaWidth >= mediaHeight) {
            w = MASK_LONG_SIDE;
            h = Math.max(1, Math.round(MASK_LONG_SIDE * mediaHeight / (float) mediaWidth));
        } else {
            h = MASK_LONG_SIDE;
            w = Math.max(1, Math.round(MASK_LONG_SIDE * mediaWidth / (float) mediaHeight));
        }
        if (maskBitmap != null && maskBitmap.getWidth() == w && maskBitmap.getHeight() == h) {
            clearMask();
            return;
        }
        maskBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        maskCanvas = new Canvas(maskBitmap);
        maskCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
    }

    private void ensureMaskBitmap() {
        if (maskBitmap == null || maskCanvas == null) recreateMaskBitmap();
    }

    private RectF findBounds(Bitmap bitmap) {
        if (bitmap == null) return null;
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        int[] row = new int[w];
        int left = w, top = h, right = -1, bottom = -1;
        for (int y = 0; y < h; y++) {
            bitmap.getPixels(row, 0, w, 0, y, w, 1);
            for (int x = 0; x < w; x++) {
                if (((row[x] >>> 24) & 0xFF) > 12) {
                    if (x < left) left = x;
                    if (x > right) right = x;
                    if (y < top) top = y;
                    if (y > bottom) bottom = y;
                }
            }
        }
        if (right < left || bottom < top) return null;
        return new RectF(left, top, right + 1, bottom + 1);
    }

    private void updateContentRect() {
        float vw = getWidth();
        float vh = getHeight();
        if (vw <= 0 || vh <= 0 || contentAspect <= 0f) {
            contentRect.setEmpty();
            return;
        }
        float viewAspect = vw / vh;
        if (contentAspect > viewAspect) {
            float h = vw / contentAspect;
            float top = (vh - h) / 2f;
            contentRect.set(0f, top, vw, top + h);
        } else {
            float w = vh * contentAspect;
            float left = (vw - w) / 2f;
            contentRect.set(left, 0f, left + w, vh);
        }
    }

    private float currentRadiusPx() {
        return dp(eraseMode ? eraseBrushDp : brushDp) * 0.5f;
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
