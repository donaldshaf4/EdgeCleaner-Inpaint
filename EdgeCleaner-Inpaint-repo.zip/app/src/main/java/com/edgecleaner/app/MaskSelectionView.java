package com.edgecleaner.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** A simple drag-to-select rectangular mask constrained to the displayed media bounds. */
public final class MaskSelectionView extends View {
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF contentRect = new RectF();
    private final RectF selection = new RectF();

    private float contentAspect = 16f / 9f;
    private float downX;
    private float downY;
    private boolean dragging;

    public MaskSelectionView(Context context) {
        super(context);
        setWillNotDraw(false);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dp(2));
        borderPaint.setColor(Color.WHITE);

        shadePaint.setStyle(Paint.Style.FILL);
        shadePaint.setColor(0x66000000);

        fillPaint.setStyle(Paint.Style.FILL);
        fillPaint.setColor(0x55FF3D00);

        // This view sits above VideoView inside a ScrollView. It must be an explicit touch target
        // so drag gestures are delivered here instead of to the video/parent scroll container.
        setClickable(true);
        setFocusable(true);
    }

    public void setContentSize(int width, int height) {
        if (width > 0 && height > 0) {
            contentAspect = width / (float) height;
            updateContentRect();
            clearMask();
            invalidate();
        }
    }

    public void clearMask() {
        selection.setEmpty();
        invalidate();
    }

    /** Sets the selection from normalized media coordinates (0..1), origin at top-left. */
    public void setNormalizedRect(RectF normalized) {
        updateContentRect();
        if (normalized == null || contentRect.isEmpty()) {
            clearMask();
            return;
        }
        RectF n = new RectF(
                clamp01(normalized.left),
                clamp01(normalized.top),
                clamp01(normalized.right),
                clamp01(normalized.bottom));
        setFromNormalized(n);
        invalidate();
    }

    public void setDefaultMask() {
        updateContentRect();
        if (contentRect.isEmpty()) return;
        float w = contentRect.width() * 0.28f;
        float h = contentRect.height() * 0.16f;
        selection.set(contentRect.right - w - dp(12), contentRect.bottom - h - dp(12),
                contentRect.right - dp(12), contentRect.bottom - dp(12));
        clampSelection();
        invalidate();
    }

    /** Returns normalized coordinates (0..1) relative to the displayed media, origin at top-left. */
    public RectF getNormalizedRect() {
        updateContentRect();
        if (selection.isEmpty() || contentRect.isEmpty()) return null;
        RectF out = new RectF(
                (selection.left - contentRect.left) / contentRect.width(),
                (selection.top - contentRect.top) / contentRect.height(),
                (selection.right - contentRect.left) / contentRect.width(),
                (selection.bottom - contentRect.top) / contentRect.height());
        out.left = clamp01(out.left);
        out.top = clamp01(out.top);
        out.right = clamp01(out.right);
        out.bottom = clamp01(out.bottom);
        if (out.width() < 0.01f || out.height() < 0.01f) return null;
        return out;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        RectF old = getNormalizedRectInternal();
        updateContentRect();
        if (old != null) setFromNormalized(old);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        updateContentRect();
        if (contentRect.isEmpty()) return;

        // Nothing is drawn until the user actually starts selecting a watermark.
        if (selection.isEmpty()) return;

        canvas.save();
        canvas.clipRect(contentRect);
        canvas.drawRect(selection, fillPaint);
        canvas.drawRect(selection, borderPaint);
        canvas.restore();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled()) return false;
        updateContentRect();
        if (contentRect.isEmpty()) return false;

        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            // Only start drawing when the finger is actually on the displayed image/video.
            if (!contentRect.contains(event.getX(), event.getY())) return false;

            // Critical for phone UI: the preview is inside a ScrollView. Without this call the
            // ScrollView steals ACTION_MOVE after a few pixels and the rectangle never appears.
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);

            downX = event.getX();
            downY = event.getY();
            selection.set(downX, downY, downX, downY);
            dragging = true;
            invalidate();
            return true;
        }

        if (!dragging) return false;

        // Keep the whole drag gesture on this overlay until the finger is released.
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        float x = clamp(event.getX(), contentRect.left, contentRect.right);
        float y = clamp(event.getY(), contentRect.top, contentRect.bottom);

        switch (action) {
            case MotionEvent.ACTION_MOVE:
                selection.set(Math.min(downX, x), Math.min(downY, y),
                        Math.max(downX, x), Math.max(downY, y));
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                dragging = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                float min = dp(12);
                if (selection.width() < min || selection.height() < min) {
                    clearMask();
                } else {
                    performClick();
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                clearMask();
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private void updateContentRect() {
        float vw = getWidth();
        float vh = getHeight();
        if (vw <= 0 || vh <= 0 || contentAspect <= 0f) {
            contentRect.setEmpty();
            return;
        }
        float viewAspect = vw / vh;
        if (contentAspect > viewAspect) {
            float h = vw / contentAspect;
            float top = (vh - h) / 2f;
            contentRect.set(0f, top, vw, top + h);
        } else {
            float w = vh * contentAspect;
            float left = (vw - w) / 2f;
            contentRect.set(left, 0f, left + w, vh);
        }
    }

    private RectF getNormalizedRectInternal() {
        if (selection.isEmpty() || contentRect.isEmpty()) return null;
        return new RectF(
                (selection.left - contentRect.left) / contentRect.width(),
                (selection.top - contentRect.top) / contentRect.height(),
                (selection.right - contentRect.left) / contentRect.width(),
                (selection.bottom - contentRect.top) / contentRect.height());
    }

    private void setFromNormalized(RectF n) {
        selection.set(
                contentRect.left + n.left * contentRect.width(),
                contentRect.top + n.top * contentRect.height(),
                contentRect.left + n.right * contentRect.width(),
                contentRect.top + n.bottom * contentRect.height());
        clampSelection();
    }

    private void clampSelection() {
        if (selection.left < contentRect.left) selection.offset(contentRect.left - selection.left, 0);
        if (selection.top < contentRect.top) selection.offset(0, contentRect.top - selection.top);
        if (selection.right > contentRect.right) selection.offset(contentRect.right - selection.right, 0);
        if (selection.bottom > contentRect.bottom) selection.offset(0, contentRect.bottom - selection.bottom);
    }

    private static float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
