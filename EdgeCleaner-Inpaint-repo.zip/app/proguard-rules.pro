# No custom rules required for the debug APK.
